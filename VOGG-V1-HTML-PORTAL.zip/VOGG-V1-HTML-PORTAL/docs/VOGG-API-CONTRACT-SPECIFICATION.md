# VOGG API CONTRACT SPECIFICATION

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Final  
**Purpose:** Complete API contract for frontend/backend integration  
**Format:** OpenAPI 3.1 Compatible  

---

## API OVERVIEW

**Base URL:** `https://api.vogg.com/v1`  
**Authentication:** Bearer Token (JWT)  
**Response Format:** JSON  
**Rate Limit:** 1,000 requests/minute per user  

---

## PART 1: AUTHENTICATION ENDPOINTS

### POST /auth/register

**Purpose:** Register new user

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "profile": {
    "firstName": "John",
    "lastName": "Doe"
  }
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "profile": {
      "firstName": "John",
      "lastName": "Doe"
    },
    "status": "pending",
    "createdAt": "2025-06-26T12:00:00Z"
  }
}
```

**Validation:**
- email: Valid format, unique
- password: Min 12 chars, uppercase, lowercase, number, special char
- firstName, lastName: 1-100 chars each

**Errors:**
- 400: Invalid input
- 409: Email already exists

---

### POST /auth/login

**Purpose:** Authenticate user and issue tokens

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "profile": { ... },
      "status": "active"
    },
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc...",
    "expiresIn": 900
  }
}
```

**Business Rules:**
- User must be verified to login
- Failed attempts tracked (max 5/hour)
- Account locked after 5 failures

**Errors:**
- 401: Invalid credentials
- 423: Account locked

---

### POST /auth/refresh

**Purpose:** Refresh access token

**Headers:**
```
Authorization: Bearer <refreshToken>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc...",
    "expiresIn": 900
  }
}
```

**Errors:**
- 401: Invalid refresh token
- 410: Token expired

---

### POST /auth/logout

**Purpose:** Invalidate tokens

**Headers:**
```
Authorization: Bearer <accessToken>
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

---

### POST /auth/verify-email

**Purpose:** Verify email address

**Request Body:**
```json
{
  "token": "verification-token-from-email"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Email verified"
}
```

---

## PART 2: USER ENDPOINTS

### GET /users/me

**Purpose:** Get current user profile

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "profile": {
      "firstName": "John",
      "lastName": "Doe",
      "avatar": "https://..."
    },
    "status": "active",
    "createdAt": "2025-06-26T12:00:00Z"
  }
}
```

---

### PUT /users/me

**Purpose:** Update user profile

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "profile": {
    "firstName": "Jane",
    "lastName": "Smith",
    "avatar": "https://..."
  }
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": { ... updated user ... }
}
```

---

## PART 3: ORGANIZATION ENDPOINTS

### POST /organizations

**Purpose:** Create new organization

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "name": "My Organization",
  "description": "Organization description",
  "type": "nonprofit",
  "metadata": {
    "country": "NG",
    "sector": "governance"
  }
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "name": "My Organization",
    "type": "nonprofit",
    "status": "active",
    "createdBy": "uuid",
    "createdAt": "2025-06-26T12:00:00Z"
  }
}
```

**Validation:**
- name: 1-255 chars, required
- type: enum (nonprofit, government, business, etc.)
- Only authenticated users can create

---

### GET /organizations

**Purpose:** List user's organizations

**Query Parameters:**
```
?page=1&limit=20&status=active&sort=createdAt
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "name": "Organization 1",
      "type": "nonprofit",
      "status": "active",
      "role": "admin"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

---

### GET /organizations/{id}

**Purpose:** Get organization details

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "name": "Organization",
    "description": "...",
    "type": "nonprofit",
    "status": "active",
    "memberCount": 42,
    "createdAt": "2025-06-26T12:00:00Z",
    "metadata": { ... }
  }
}
```

---

### GET /organizations/{id}/members

**Purpose:** List organization members

**Query Parameters:**
```
?page=1&limit=50&role=member
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "email": "user@example.com",
      "profile": { ... },
      "role": "member",
      "joinedAt": "2025-06-26T12:00:00Z"
    }
  ],
  "pagination": { ... }
}
```

---

### POST /organizations/{id}/members

**Purpose:** Add member to organization

**Request Body:**
```json
{
  "email": "newmember@example.com",
  "role": "member"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "userId": "uuid",
    "organizationId": "uuid",
    "role": "member",
    "joinedAt": "2025-06-26T12:00:00Z"
  }
}
```

**Authorization:** Requires admin role in organization

---

## PART 4: GOVERNANCE ENDPOINTS

### POST /governance/votes

**Purpose:** Create new vote

**Request Body:**
```json
{
  "organizationId": "uuid",
  "title": "Should we approve the budget?",
  "description": "Annual budget review 2025",
  "voteType": "single_choice",
  "options": ["Yes", "No", "Abstain"],
  "startsAt": "2025-06-27T00:00:00Z",
  "endsAt": "2025-06-28T23:59:59Z",
  "eligibilityCriteria": {
    "role": "member",
    "minJoinDays": 0
  }
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "organizationId": "uuid",
    "title": "Should we approve the budget?",
    "status": "draft",
    "voteType": "single_choice",
    "options": ["Yes", "No", "Abstain"],
    "startsAt": "2025-06-27T00:00:00Z",
    "endsAt": "2025-06-28T23:59:59Z",
    "createdAt": "2025-06-26T12:00:00Z"
  }
}
```

**Validation:**
- title: 1-255 chars
- options: 2-50 items
- startsAt > current time
- endsAt > startsAt
- voteType: single_choice | multiple_choice | ranked

**Authorization:** Requires vote:create permission

---

### POST /governance/votes/{id}/publish

**Purpose:** Publish vote (make it active for voting)

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "status": "active",
    "publishedAt": "2025-06-26T12:00:00Z"
  }
}
```

**Business Rules:**
- Vote must be in draft status
- Current time < vote start time
- Cannot be edited after publish

**Authorization:** Requires vote:publish permission

---

### POST /governance/votes/{id}/vote

**Purpose:** Cast vote

**Request Body:**
```json
{
  "choice": "Yes"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "voteId": "uuid",
    "userId": "uuid",
    "choice": "Yes",
    "votedAt": "2025-06-26T12:00:00Z"
  }
}
```

**Validation:**
- choice must match one of vote options
- vote must be active (within voting window)
- user must be eligible
- user must not have already voted

**Errors:**
- 409: User already voted
- 410: Voting window closed
- 403: User not eligible

---

### GET /governance/votes

**Purpose:** List votes

**Query Parameters:**
```
?organizationId=uuid&status=active&page=1&limit=20
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "title": "Budget Approval",
      "status": "active",
      "voteType": "single_choice",
      "participantCount": 42,
      "startsAt": "2025-06-27T00:00:00Z",
      "endsAt": "2025-06-28T23:59:59Z",
      "createdAt": "2025-06-26T12:00:00Z"
    }
  ],
  "pagination": { ... }
}
```

---

### GET /governance/votes/{id}

**Purpose:** Get vote details

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "organizationId": "uuid",
    "title": "Budget Approval",
    "description": "Annual budget review",
    "voteType": "single_choice",
    "status": "active",
    "options": ["Yes", "No", "Abstain"],
    "startsAt": "2025-06-27T00:00:00Z",
    "endsAt": "2025-06-28T23:59:59Z",
    "participantCount": 42,
    "userVoted": true,
    "userChoice": "Yes",
    "createdAt": "2025-06-26T12:00:00Z"
  }
}
```

**Authorization:** Requires org membership

---

### GET /governance/votes/{id}/results

**Purpose:** Get vote results

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "voteId": "uuid",
    "status": "active",
    "results": {
      "Yes": { "count": 25, "percentage": 59.5 },
      "No": { "count": 12, "percentage": 28.6 },
      "Abstain": { "count": 5, "percentage": 11.9 }
    },
    "totalVotes": 42,
    "eligibleVoters": 50,
    "participationRate": 84
  }
}
```

**Business Rule:** Results only visible after vote closes (status = closed)

---

### GET /governance/votes/{id}/audit

**Purpose:** Get vote audit trail

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "action": "created",
      "timestamp": "2025-06-26T10:00:00Z",
      "userId": "uuid",
      "changes": { ... }
    },
    {
      "action": "published",
      "timestamp": "2025-06-26T11:00:00Z",
      "userId": "uuid"
    },
    {
      "action": "closed",
      "timestamp": "2025-06-28T23:59:59Z",
      "system": true
    }
  ]
}
```

---

## PART 5: ERROR HANDLING

**Error Response Format:**
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable message",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ]
  },
  "meta": {
    "timestamp": "2025-06-26T12:00:00Z",
    "requestId": "req_xyz"
  }
}
```

**Common Error Codes:**
- 400: INVALID_INPUT
- 401: UNAUTHORIZED
- 403: FORBIDDEN
- 404: NOT_FOUND
- 409: CONFLICT
- 429: RATE_LIMIT_EXCEEDED
- 500: INTERNAL_ERROR

---

## PART 6: AUTHENTICATION DETAILS

**JWT Token Structure:**
```json
{
  "sub": "user_uuid",
  "email": "user@example.com",
  "roles": ["member", "admin"],
  "organizationId": "org_uuid",
  "iat": 1719399600,
  "exp": 1719400500
}
```

**Token Expiry:**
- Access Token: 15 minutes
- Refresh Token: 7 days

**Header:**
```
Authorization: Bearer <accessToken>
```

---

## PART 7: RATE LIMITING

**Limits:**
- Per user: 1,000 requests/minute
- Per API key: 100,000 requests/minute

**Headers:**
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1719399600
```

---

## PART 8: EXAMPLE WORKFLOWS

### Complete Registration → Organization → Vote Workflow

**Step 1: Register**
```
POST /auth/register
{
  "email": "admin@org.com",
  "password": "SecurePass123!",
  "profile": { "firstName": "Jane", "lastName": "Doe" }
}
Response: accessToken, refreshToken
```

**Step 2: Create Organization**
```
POST /organizations
Authorization: Bearer <token>
{
  "name": "Community Council",
  "type": "nonprofit"
}
Response: organizationId
```

**Step 3: Create Vote**
```
POST /governance/votes
Authorization: Bearer <token>
{
  "organizationId": "<orgId>",
  "title": "Approve Charter",
  "voteType": "single_choice",
  "options": ["Approve", "Reject"],
  "startsAt": "2025-06-27T00:00:00Z",
  "endsAt": "2025-06-28T23:59:59Z"
}
Response: voteId (status: draft)
```

**Step 4: Publish Vote**
```
POST /governance/votes/<voteId>/publish
Authorization: Bearer <token>
Response: status changed to active
```

**Step 5: Add Members**
```
POST /organizations/<orgId>/members
Authorization: Bearer <token>
{
  "email": "voter@org.com",
  "role": "member"
}
```

**Step 6: Members Vote**
```
POST /governance/votes/<voteId>/vote
Authorization: Bearer <token>
{
  "choice": "Approve"
}
```

**Step 7: View Results (after vote closes)**
```
GET /governance/votes/<voteId>/results
Authorization: Bearer <token>
Response: Results with counts and percentages
```

---

**API Contract Complete**  
**Status:** ✅ Ready for Frontend/Backend Integration

