# VOGG Community Code of Conduct

## Our Commitment

VOGG is committed to providing a welcoming and inclusive environment for all contributors.

## Expected Behavior

- Be respectful and professional
- Welcome feedback and differing perspectives
- Focus on constructive criticism
- Support other community members

## Unacceptable Behavior

- Harassment or discrimination
- Personal attacks or trolling
- Sharing confidential information
- Unwelcome sexual comments

## Enforcement

Violations may result in temporary or permanent removal from the project.

## Reporting

Report violations to project maintainers through GitHub Issues or direct contact.

---

This code applies to all VOGG project spaces.
