# VOGG ENTERPRISE API SPECIFICATION (OpenAPI 3.1)

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Production-Ready  
**Base URL:** `https://api.vogg.com/v1`  

---

## OVERVIEW

Complete OpenAPI 3.1 specification for all VOGG endpoints.

This specification serves as the contract between frontend and backend teams.

---

## AUTHENTICATION

**Method:** Bearer Token (JWT)

```
Authorization: Bearer <jwt_token>
```

**Token Structure:**
```json
{
  "sub": "user_uuid",
  "email": "user@example.com",
  "roles": ["member"],
  "entity_id": "org_uuid",
  "exp": 1625000900
}
```

---

## RESPONSE FORMAT

**Success (2xx):**
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "timestamp": "2025-06-26T12:00:00Z",
    "version": "1.0"
  }
}
```

**Error (4xx, 5xx):**
```json
{
  "success": false,
  "error": {
    "code": "INVALID_INPUT",
    "message": "Email is required",
    "details": [
      { "field": "email", "message": "Required" }
    ]
  },
  "meta": {
    "timestamp": "2025-06-26T12:00:00Z",
    "request_id": "req_xyz"
  }
}
```

---

## API ENDPOINTS (MVP)

### AUTHENTICATION

**POST /auth/register**
- Register new user
- Body: { email, password, firstName, lastName }
- Returns: { user, token }
- Status: 201 Created

**POST /auth/login**
- User login
- Body: { email, password }
- Returns: { user, accessToken, refreshToken }
- Status: 200 OK

**POST /auth/refresh**
- Refresh access token
- Body: { refreshToken }
- Returns: { accessToken, refreshToken }
- Status: 200 OK

**POST /auth/logout**
- User logout
- Auth Required: YES
- Returns: { success: true }
- Status: 200 OK

---

### ENTITIES (Organizations)

**GET /entities**
- List organizations
- Query: page, limit, status, type, sector
- Returns: { data: [...], pagination: {...} }
- Rate Limit: 1000/min

**POST /entities**
- Create organization
- Auth Required: YES
- Body: { name, type, metadata }
- Returns: { entity }
- Status: 201 Created

**GET /entities/{id}**
- Get organization details
- Returns: { entity }
- Status: 200 OK

**PUT /entities/{id}**
- Update organization
- Auth Required: YES (admin)
- Body: { name, description, metadata }
- Returns: { entity }
- Status: 200 OK

---

### USERS

**GET /users/me**
- Get current user profile
- Auth Required: YES
- Returns: { user }
- Status: 200 OK

**PUT /users/me**
- Update user profile
- Auth Required: YES
- Body: { profile: { firstName, lastName, avatar } }
- Returns: { user }
- Status: 200 OK

**GET /entities/{id}/users**
- List organization members
- Returns: { data: [...], pagination: {...} }
- Status: 200 OK

**POST /entities/{id}/users**
- Add member to organization
- Auth Required: YES (org admin)
- Body: { email, role }
- Returns: { user }
- Status: 201 Created

---

### VOTES (Governance)

**GET /entities/{id}/votes**
- List votes for organization
- Query: status, sort, page, limit
- Returns: { data: [...], pagination: {...} }
- Status: 200 OK

**POST /entities/{id}/votes**
- Create vote
- Auth Required: YES
- Body: { title, description, options, starts_at, ends_at }
- Returns: { vote }
- Status: 201 Created

**GET /votes/{id}**
- Get vote details
- Returns: { vote, results }
- Status: 200 OK

**POST /votes/{id}/vote**
- Cast vote
- Auth Required: YES
- Body: { choice }
- Returns: { success: true }
- Status: 200 OK

**GET /votes/{id}/results**
- Get real-time results
- Returns: { vote, results, participant_count }
- Status: 200 OK

---

## RATE LIMITING

**Per User:**
- 1,000 requests/minute
- 50,000 requests/day

**Per API Key:**
- 100,000 requests/minute
- 1,000,000 requests/day

**Headers:**
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1624689600
```

---

## ERROR CODES

| Code | HTTP | Meaning |
|------|------|---------|
| INVALID_INPUT | 400 | Validation failed |
| UNAUTHORIZED | 401 | Missing/invalid auth |
| FORBIDDEN | 403 | Permission denied |
| NOT_FOUND | 404 | Resource not found |
| CONFLICT | 409 | Already exists |
| RATE_LIMITED | 429 | Too many requests |
| SERVER_ERROR | 500 | Internal error |

---

## VERSIONING

- Current: `/v1/`
- Future: `/v2/` (6-month deprecation notice)
- Sunset Header: `Sunset: Sun, 26 Dec 2025 23:59:59 GMT`

---

**API Specification Complete**  
**Status:** ✅ Production-Ready  
**Format:** OpenAPI 3.1  
**Total Endpoints (MVP):** 20+

