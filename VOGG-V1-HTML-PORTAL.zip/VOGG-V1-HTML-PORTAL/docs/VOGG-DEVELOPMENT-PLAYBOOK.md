# VOGG DEVELOPMENT PLAYBOOK

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Final  
**Purpose:** Official engineering standards and processes  

---

## PART 1: CODE ORGANIZATION

### Repository Structure

```
vogg-platform/
├── apps/
│   ├── backend/                    # Node.js + Express backend
│   │   ├── src/
│   │   │   ├── app.ts              # Express application setup
│   │   │   ├── server.ts           # Server entry point
│   │   │   ├── modules/            # Feature modules
│   │   │   ├── middleware/         # Express middleware
│   │   │   ├── config/             # Configuration
│   │   │   ├── shared/             # Shared utilities
│   │   │   └── types/              # TypeScript types
│   │   ├── tests/                  # Test files
│   │   ├── package.json
│   │   └── tsconfig.json
│   └── frontend/                   # React/Vue frontend
│       ├── src/
│       ├── public/
│       └── package.json
│
├── packages/                       # Shared code
│   ├── types/                      # Shared TypeScript types
│   ├── config/                     # Shared configuration
│   └── api-client/                 # Frontend API client
│
├── database/
│   ├── prisma/
│   │   └── schema.prisma           # Database schema
│   ├── migrations/                 # Database migrations
│   └── seeds/                      # Seed scripts
│
├── infrastructure/
│   ├── docker/
│   │   ├── Dockerfile              # Production image
│   │   └── Dockerfile.dev          # Development image
│   ├── kubernetes/                 # K8s manifests
│   └── terraform/                  # Infrastructure as Code
│
├── docs/                           # Documentation
│   ├── DEVELOPER-GUIDE.md
│   ├── API-REFERENCE.md
│   ├── ARCHITECTURE.md
│   └── TROUBLESHOOTING.md
│
├── .github/
│   └── workflows/                  # GitHub Actions
│
├── scripts/                        # Utility scripts
├── package.json                    # Root workspace
└── pnpm-workspace.yaml             # Workspace configuration
```

---

## PART 2: BRANCHING STRATEGY

### GitFlow Workflow

```
main (production) ────────────────────────────────────
  ↑         ↑              ↑
  │         └─── release/v1.0.1 ───┘
  │
  └─────── develop (staging) ──────────────────────────
             ↑   ↑   ↑              ↑
             │   │   │              └─ bugfix/login-error
             │   │   └────────────────── feature/marketplace
             │   └────────────────────── feature/voting
             └───────────────────────── hotfix/critical-bug (if urgent)
```

### Branch Naming

```
feature/<feature-name>        # New feature
bugfix/<bug-name>             # Bug fix in develop
hotfix/<issue>                # Critical fix from main
release/v<version>            # Release candidate
chore/<task>                  # Non-feature work
```

### Rules

1. **main:** Production ready only
   - Protected branch
   - Requires PR review (2 approvals)
   - All tests must pass
   - Version tagged

2. **develop:** Integration branch
   - Staging deploy on push
   - Feature branches merge here
   - Code review required

3. **feature/***:** Development branches
   - Branch from: develop
   - Merge back to: develop (via PR)
   - Lifetime: 1-2 weeks

4. **hotfix/***:** Urgent fixes
   - Branch from: main (if critical)
   - Merge to: main + develop
   - Code review: 1 (emergency)

---

## PART 3: COMMIT CONVENTIONS

### Conventional Commits Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

```
feat:      New feature
fix:       Bug fix
docs:      Documentation
style:     Code style (formatting, semicolons, etc)
refactor:  Code refactoring without feature change
perf:      Performance improvement
test:      Test addition or change
chore:     Dependency update, build config, etc
ci:        CI/CD configuration
```

### Examples

```
feat(voting): add vote casting endpoint

Implements POST /governance/votes/{id}/vote
- Validates eligibility
- Prevents duplicate votes
- Records audit trail

Closes #123

---

fix(auth): correct JWT expiry calculation

Refresh token expiry was incorrectly adding
days instead of seconds.

Fixes #456

---

docs(api): update endpoint documentation

Add request/response examples for auth endpoints.

---

chore(deps): upgrade prisma to 5.0.0

Updates Prisma with bug fixes and performance improvements.
```

### Commit Guidelines

- **Atomic:** One logical change per commit
- **Clear:** Describe WHAT and WHY, not HOW
- **Testable:** Each commit should pass tests
- **Linked:** Reference issues/PRs

**Bad:**
```
git commit -m "Updates"
git commit -m "Fixes stuff"
git commit -m "WIP"
```

**Good:**
```
git commit -m "feat(voting): implement vote casting with validation"
git commit -m "fix(auth): correct refresh token expiry calculation"
git commit -m "test(voting): add integration tests for vote creation"
```

---

## PART 4: PULL REQUEST PROCESS

### PR Requirements

Every PR must have:

1. **Descriptive Title**
   ```
   [TYPE] Brief description
   Example: [FEAT] Add vote casting endpoint
   ```

2. **Detailed Description**
   ```
   ## What
   Brief description of changes
   
   ## Why
   Business reason or problem solved
   
   ## How
   Technical approach taken
   
   ## Testing
   How was this tested?
   
   ## Screenshots (if UI)
   Visual evidence
   
   ## Checklist
   - [ ] Code compiles
   - [ ] Tests pass (80%+ coverage)
   - [ ] No breaking changes
   - [ ] Documentation updated
   - [ ] No hardcoded secrets
   ```

3. **Linked Issues**
   ```
   Closes #123
   Related to #456
   ```

4. **Code Changes**
   - Max 400 lines (split if larger)
   - Single feature/fix per PR
   - No unrelated changes

### Review Process

```
Developer submits PR
    ↓
Automated checks run (lint, build, tests)
    ↓
Code review (minimum 2 approvals)
    │
    ├─ Requested changes → Developer updates
    │
    └─ Approved → Merge to develop
    
Merged to develop
    ↓
Staging deploy (automatic)
    ↓
QA testing
    ↓
Ready for main (release)
```

### Code Review Checklist

**Reviewer must verify:**

- ✅ Code compiles without errors
- ✅ Tests pass (no new warnings)
- ✅ Test coverage maintained (80%+)
- ✅ No hardcoded secrets, passwords, API keys
- ✅ Business logic correct
- ✅ Error handling adequate
- ✅ Database queries optimized
- ✅ No SQL injection risks
- ✅ Permission checks in place
- ✅ Audit logging added
- ✅ Documentation updated
- ✅ No unnecessary dependencies
- ✅ Code follows style guide
- ✅ Performance acceptable
- ✅ No deprecated APIs used

---

## PART 5: DEFINITION OF DONE

Work is "Done" only when:

### Code

- ✅ Compiles without errors
- ✅ Passes all tests
- ✅ 80%+ test coverage
- ✅ Code review approved (2 reviewers)
- ✅ Merged to develop
- ✅ Passes staging deploy

### Testing

- ✅ Unit tests written
- ✅ Integration tests written
- ✅ Manual testing completed
- ✅ Edge cases tested
- ✅ Error cases tested

### Documentation

- ✅ Code comments added (where needed)
- ✅ API documentation updated
- ✅ User-facing changes documented
- ✅ Known issues documented

### Security

- ✅ No secrets in code
- ✅ Input validation added
- ✅ Authorization checks in place
- ✅ Audit logging added
- ✅ Security review passed

### Performance

- ✅ API response time acceptable
- ✅ Database queries optimized
- ✅ No N+1 query problems
- ✅ Memory usage acceptable

---

## PART 6: CODE STYLE GUIDE

### TypeScript

**Naming:**
```typescript
// Classes: PascalCase
class VoteService { }

// Variables/functions: camelCase
const voteCount = 5;
function castVote() { }

// Constants: UPPER_SNAKE_CASE
const MAX_VOTE_DURATION = 86400; // seconds

// Interfaces: IPascalCase or just PascalCase
interface IVote { }
interface Vote { }  // Preferred
```

**Formatting:**
```typescript
// Use 2 spaces
// Use semicolons
// Use single quotes
// Use strict mode

// Explicit types
const count: number = 0;
const name: string = "vote";

// Avoid any
let data: any;  // ❌ Bad
let data: Vote[];  // ✅ Good
```

**Imports:**
```typescript
// Group imports
import { Express, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';

// Local imports
import { VoteService } from './vote.service';
import { IVote } from '../types';
```

---

## PART 7: TESTING STANDARDS

### Unit Tests

```typescript
describe('VoteService', () => {
  let service: VoteService;
  
  beforeEach(() => {
    service = new VoteService();
  });
  
  it('should create vote with valid data', () => {
    const result = service.createVote(testData);
    expect(result.id).toBeDefined();
    expect(result.status).toBe('draft');
  });
  
  it('should throw error with invalid data', () => {
    expect(() => {
      service.createVote(invalidData);
    }).toThrow();
  });
});
```

### Integration Tests

```typescript
describe('Vote API Integration', () => {
  it('should create and retrieve vote', async () => {
    const vote = await createVote(testData);
    const retrieved = await getVote(vote.id);
    expect(retrieved.title).toBe(testData.title);
  });
});
```

### Coverage Target

- **Minimum:** 80%
- **Target:** 90%
- **Critical paths:** 100%

---

## PART 8: RELEASE PROCESS

### Version Numbers

**Semantic Versioning: MAJOR.MINOR.PATCH**
```
v1.0.0  → v1.1.0  (new feature, backward compatible)
v1.1.0  → v1.1.1  (bug fix)
v1.1.1  → v2.0.0  (breaking change)
```

### Release Checklist

```
[ ] All PRs merged to develop
[ ] Staging tested (2 hours)
[ ] Version number updated
[ ] CHANGELOG.md updated
[ ] Commit: "chore: release v1.0.1"
[ ] Tag: "git tag v1.0.1"
[ ] Push: "git push origin main --tags"
[ ] GitHub release created
[ ] Announce to team
[ ] Monitor for issues (1 hour)
```

---

**Development Playbook Complete**  
**Status:** ✅ Official team standards documented

