# Contributing to VOGG

## Before Contributing

1. Read [README.md](README.md)
2. Review [EXECUTIVE_SUMMARY.md](EXECUTIVE_SUMMARY.md)
3. Check development guide in `/docs/guides/`
4. Review coding standards in `/docs/governance/`

## Contribution Areas

- Backend development (Express + TypeScript)
- Frontend development (React)
- Infrastructure (Docker, Terraform, Kubernetes)
- Testing (Unit, Integration, E2E)
- Documentation improvements

## Development Workflow

1. Create feature branch: `git checkout -b feature/your-feature`
2. Follow coding standards (see `/docs/governance/CODING_STANDARDS.md`)
3. Write tests (80%+ coverage)
4. Commit with conventional format: `git commit -m "feat(module): description"`
5. Create pull request
6. Get 2 approvals before merge

## Definition of Done

Every task must have:
- ✅ Code compiles (zero errors)
- ✅ Tests pass (80%+ coverage)
- ✅ Code reviewed (2 approvals)
- ✅ Documentation updated
- ✅ Security review passed
- ✅ Linting passed

## Questions?

Refer to documentation in `/docs/` folder.
