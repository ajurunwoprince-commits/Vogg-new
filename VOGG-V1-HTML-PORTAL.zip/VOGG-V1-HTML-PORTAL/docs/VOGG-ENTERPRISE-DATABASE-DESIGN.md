# VOGG ENTERPRISE DATABASE DESIGN SPECIFICATION

**Date:** June 26, 2025  
**Version:** 1.0 (Production-Ready)  
**Status:** ✅ Approved  
**Owner:** Database Architect / Backend Lead  
**Purpose:** Production-ready database specification for all development teams  

---

## PART 1: DATABASE DESIGN PRINCIPLES

### Core Principles

**1. ACID Compliance**
- All transactions must be ACID-compliant
- Critical for voting integrity
- PostgreSQL provides native ACID guarantees

**2. Universal Organization Model**
- Single `entities` table supports all organization types
- JSONB metadata for flexibility
- No schema redesign needed for new sectors

**3. Multi-Tenancy**
- Organization-level data isolation
- All queries filtered by organization context
- Row-level security (future phase)

**4. Immutable Audit Trail**
- All changes logged to `audit_logs`
- Cannot be updated or deleted
- Compliance requirement for governance

**5. Soft Deletes**
- Records marked deleted, not removed
- Preserve history and referential integrity
- `deleted_at` timestamp on all major tables

**6. Performance First**
- Indexes on frequently queried fields
- Denormalization where necessary
- Partitioning for large tables

**7. Security**
- Encryption at rest (database-level)
- Encryption in transit (TLS)
- No sensitive data in logs

---

## PART 2: DATABASE TECHNOLOGY SELECTION

### PostgreSQL 15+

**Why PostgreSQL:**
- ACID compliance for voting integrity
- JSON/JSONB for flexible schema
- Full-text search capabilities
- Partitioning for scale
- Excellent performance and stability
- Enterprise support available

**Deployment:**
- MVP: Single RDS instance (db.t3.small)
- Production: Multi-AZ with read replicas (db.t3.large+)
- Backup: Automated daily snapshots

### Redis 7+ (Cache + Sessions)

**Use Cases:**
- Session storage (HttpOnly cookies)
- Cache for frequently accessed data
- Rate limiting counters
- Pub/Sub for real-time features
- Job queue (Bull/BullMQ)

**Deployment:**
- MVP: Single ElastiCache node (cache.t3.small)
- Production: ElastiCache cluster (multi-node, auto-failover)

### Elasticsearch 8+ (Phase 2)

**Use Cases:**
- Full-text search
- Organization/user search
- Complex filtering
- Analytics

**MVP Alternative:** PostgreSQL full-text search (simpler, sufficient)

---

## PART 3: COMPLETE TABLE DEFINITIONS

### Universal Core Tables

#### Table 1: entities

```sql
CREATE TABLE entities (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Type classification
  type VARCHAR(50) NOT NULL,  -- 'organization', 'government', 'ngo', 'company', etc.
  
  -- Basic information
  name VARCHAR(255) NOT NULL,
  description TEXT,
  slug VARCHAR(255) UNIQUE,  -- URL-friendly identifier
  
  -- Metadata (flexible, sector-specific)
  metadata JSONB NOT NULL DEFAULT '{}',  -- { "sector": "governance", "country": "NG", "industry": "tech" }
  
  -- Status management
  status VARCHAR(20) NOT NULL DEFAULT 'active',  -- 'active', 'suspended', 'archived'
  verified_at TIMESTAMP,  -- When organization was verified
  verification_level VARCHAR(20),  -- 'unverified', 'basic', 'verified', 'trusted'
  
  -- Hierarchy (parent-child relationships)
  parent_entity_id UUID REFERENCES entities(id),  -- For sub-organizations
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMP,  -- Soft delete
  
  -- Constraints
  CONSTRAINT valid_type CHECK (type IN ('organization', 'government', 'ngo', 'company', 'religious', 'educational', 'investment', 'realtor', 'community')),
  CONSTRAINT valid_status CHECK (status IN ('active', 'suspended', 'archived')),
  CONSTRAINT valid_verification CHECK (verification_level IN ('unverified', 'basic', 'verified', 'trusted'))
);

-- Indexes
CREATE INDEX idx_entities_type ON entities(type);
CREATE INDEX idx_entities_status ON entities(status);
CREATE INDEX idx_entities_created_at ON entities(created_at);
CREATE INDEX idx_entities_parent ON entities(parent_entity_id);
CREATE INDEX idx_entities_slug ON entities(slug);
CREATE INDEX idx_entities_metadata_sector ON entities USING GIN(metadata);  -- JSONB indexing
```

#### Table 2: users

```sql
CREATE TABLE users (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Email and authentication
  email VARCHAR(255) UNIQUE NOT NULL,
  email_verified_at TIMESTAMP,
  password_hash VARCHAR(255),  -- NULL for OAuth users
  
  -- Profile
  profile JSONB NOT NULL DEFAULT '{}',  -- { "firstName": "John", "lastName": "Doe", "avatar": "...", "phone": "+234..." }
  
  -- Organization membership
  -- (users can belong to multiple organizations via user_roles table)
  
  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'pending',  -- 'pending', 'active', 'suspended', 'deleted'
  verified BOOLEAN DEFAULT FALSE,
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMP,  -- Soft delete
  
  -- Last activity
  last_login_at TIMESTAMP,
  last_login_ip INET,
  
  -- Constraints
  CONSTRAINT valid_status CHECK (status IN ('pending', 'active', 'suspended', 'deleted'))
);

-- Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_created_at ON users(created_at);
CREATE INDEX idx_users_last_login ON users(last_login_at);
```

#### Table 3: roles

```sql
CREATE TABLE roles (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Organization context
  entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  
  -- Role definition
  name VARCHAR(50) NOT NULL,  -- 'admin', 'member', 'voter', 'moderator', 'viewer'
  description TEXT,
  
  -- Permissions (flexible JSON)
  permissions JSONB NOT NULL DEFAULT '{}',  -- { "entity:read": true, "vote:create": true, ... }
  
  -- Hierarchy
  parent_role_id UUID REFERENCES roles(id),  -- For role inheritance
  
  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  UNIQUE(entity_id, name),  -- One role name per organization
  CONSTRAINT valid_status CHECK (status IN ('active', 'archived'))
);

-- Indexes
CREATE INDEX idx_roles_entity ON roles(entity_id);
CREATE INDEX idx_roles_name ON roles(name);
```

#### Table 4: user_roles

```sql
CREATE TABLE user_roles (
  -- Composite key
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  
  -- Assignment details
  assigned_by UUID REFERENCES users(id),  -- Who assigned this role
  assigned_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Expiration (optional)
  expires_at TIMESTAMP,
  
  -- Primary key
  PRIMARY KEY (user_id, role_id, entity_id),
  
  -- Constraint
  FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE
);

-- Indexes
CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_user_roles_entity ON user_roles(entity_id);
CREATE INDEX idx_user_roles_expires ON user_roles(expires_at);
```

#### Table 5: entity_relationships

```sql
CREATE TABLE entity_relationships (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Entities in relationship
  source_entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  target_entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  
  -- Relationship type
  relationship_type VARCHAR(50) NOT NULL,  -- 'governs', 'member_of', 'sponsors', 'partners_with', 'owns'
  
  -- Metadata (relationship-specific)
  metadata JSONB NOT NULL DEFAULT '{}',  -- Can store relationship-specific data
  
  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_type CHECK (relationship_type IN ('governs', 'member_of', 'sponsors', 'partners_with', 'owns', 'reports_to', 'collaborates_with')),
  CONSTRAINT valid_status CHECK (status IN ('active', 'suspended', 'archived')),
  CONSTRAINT no_self_relationship CHECK (source_entity_id != target_entity_id)
);

-- Indexes
CREATE INDEX idx_relationships_source ON entity_relationships(source_entity_id);
CREATE INDEX idx_relationships_target ON entity_relationships(target_entity_id);
CREATE INDEX idx_relationships_type ON entity_relationships(relationship_type);
```

---

### Governance Module Tables

#### Table 6: votes

```sql
CREATE TABLE votes (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Organization context
  entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  
  -- Vote details
  title VARCHAR(255) NOT NULL,
  description TEXT,
  
  -- Voting configuration
  vote_type VARCHAR(20) NOT NULL DEFAULT 'single_choice',  -- 'single_choice', 'multiple_choice', 'ranked'
  options JSONB NOT NULL,  -- ["Yes", "No", "Abstain"] or { "1": "Option A", "2": "Option B" }
  
  -- Eligibility
  eligible_voter_count INT DEFAULT 0,  -- Snapshot at creation
  eligibility_criteria JSONB,  -- { "role": "member", "verified": true }
  
  -- Timing
  created_by UUID REFERENCES users(id),
  starts_at TIMESTAMP NOT NULL,
  ends_at TIMESTAMP NOT NULL,
  
  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'draft',  -- 'draft', 'active', 'closed', 'cancelled'
  
  -- Results (calculated, not manually entered)
  vote_count INT DEFAULT 0,  -- Total votes cast
  results JSONB,  -- { "Yes": 1000, "No": 500, "Abstain": 100 }
  winner VARCHAR(255),  -- For simple votes
  
  -- Transparency
  public BOOLEAN DEFAULT TRUE,
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_type CHECK (vote_type IN ('single_choice', 'multiple_choice', 'ranked')),
  CONSTRAINT valid_status CHECK (status IN ('draft', 'active', 'closed', 'cancelled')),
  CONSTRAINT valid_timing CHECK (starts_at < ends_at)
);

-- Indexes
CREATE INDEX idx_votes_entity ON votes(entity_id);
CREATE INDEX idx_votes_status ON votes(status);
CREATE INDEX idx_votes_starts_at ON votes(starts_at);
CREATE INDEX idx_votes_ends_at ON votes(ends_at);
CREATE INDEX idx_votes_created_at ON votes(created_at);
```

#### Table 7: vote_records

```sql
CREATE TABLE vote_records (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Vote participation
  vote_id UUID NOT NULL REFERENCES votes(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Vote cast
  choice VARCHAR(255) NOT NULL,  -- User's choice
  
  -- Recording
  voted_at TIMESTAMP NOT NULL DEFAULT NOW(),
  ip_address INET,  -- For audit
  
  -- Constraints
  UNIQUE(vote_id, user_id),  -- One vote per user per vote
  CONSTRAINT has_choice CHECK (choice != '')
);

-- Indexes
CREATE INDEX idx_vote_records_vote ON vote_records(vote_id);
CREATE INDEX idx_vote_records_user ON vote_records(user_id);
CREATE INDEX idx_vote_records_voted_at ON vote_records(voted_at);
```

---

### Security & Audit Tables

#### Table 8: audit_logs

```sql
CREATE TABLE audit_logs (
  -- Identifier (not UUID to ensure immutability)
  id BIGSERIAL PRIMARY KEY,
  
  -- What changed
  table_name VARCHAR(50) NOT NULL,  -- 'entities', 'votes', 'users', etc.
  record_id UUID NOT NULL,  -- ID of affected record
  action VARCHAR(20) NOT NULL,  -- 'INSERT', 'UPDATE', 'DELETE'
  
  -- Before and after
  old_values JSONB,  -- Previous state (NULL for INSERT)
  new_values JSONB,  -- New state (NULL for DELETE)
  
  -- Who and how
  user_id UUID REFERENCES users(id),
  ip_address INET,
  user_agent TEXT,
  
  -- Status
  status VARCHAR(20) NOT NULL,  -- 'success', 'failure'
  error_message TEXT,
  
  -- Timestamp (immutable)
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_action CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
  CONSTRAINT valid_status CHECK (status IN ('success', 'failure'))
);

-- Indexes (for querying, not modification)
CREATE INDEX idx_audit_table_record ON audit_logs(table_name, record_id);
CREATE INDEX idx_audit_created_at ON audit_logs(created_at);
CREATE INDEX idx_audit_user ON audit_logs(user_id);

-- Security: Prevent modification
REVOKE UPDATE, DELETE ON audit_logs FROM app_user;
GRANT SELECT, INSERT ON audit_logs TO app_user;
```

#### Table 9: sessions

```sql
CREATE TABLE sessions (
  -- Session token (hashed)
  session_id VARCHAR(255) PRIMARY KEY,
  
  -- User
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Session data
  data JSONB,  -- { "ip": "...", "user_agent": "..." }
  
  -- Expiration
  expires_at TIMESTAMP NOT NULL,
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_activity_at TIMESTAMP DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_expiry CHECK (expires_at > created_at)
);

-- Indexes
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);
```

---

### Communication & Notification Tables

#### Table 10: messages

```sql
CREATE TABLE messages (
  -- Identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Participants
  sender_id UUID NOT NULL REFERENCES users(id),
  recipient_id UUID NOT NULL REFERENCES users(id),
  entity_id UUID REFERENCES entities(id),  -- Organization context (optional)
  
  -- Content
  subject VARCHAR(255),
  body TEXT NOT NULL,
  
  -- Status
  read_at TIMESTAMP,
  archived BOOLEAN DEFAULT FALSE,
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT no_self_message CHECK (sender_id != recipient_id)
);

-- Indexes
CREATE INDEX idx_messages_recipient ON messages(recipient_id);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_read ON messages(read_at);
CREATE INDEX idx_messages_created ON messages(created_at);
```

---

### Notification Preferences

#### Table 11: notification_preferences

```sql
CREATE TABLE notification_preferences (
  -- Composite key
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  
  -- Notification channels
  email_enabled BOOLEAN DEFAULT TRUE,
  email_frequency VARCHAR(20) DEFAULT 'immediate',  -- 'immediate', 'daily', 'weekly', 'never'
  
  sms_enabled BOOLEAN DEFAULT FALSE,
  sms_number VARCHAR(20),
  
  push_enabled BOOLEAN DEFAULT TRUE,
  
  in_app_enabled BOOLEAN DEFAULT TRUE,
  
  -- Notification types
  notifications JSONB NOT NULL DEFAULT '{}',  -- { "vote_created": true, "vote_ended": true, ... }
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Index
CREATE INDEX idx_notification_prefs_user ON notification_preferences(user_id);
```

---

## PART 4: DATABASE INDEXING STRATEGY

### Index Classes

**B-Tree Indexes (Default)**
```sql
-- Exact match and range queries
CREATE INDEX idx_entities_type ON entities(type);
CREATE INDEX idx_entities_created_at ON entities(created_at);
```

**JSONB Indexes (GIN)**
```sql
-- Flexible JSON field queries
CREATE INDEX idx_entities_metadata ON entities USING GIN(metadata);
```

**Partial Indexes (Filtered)**
```sql
-- Only active entities
CREATE INDEX idx_entities_active ON entities(id) WHERE status = 'active';

-- Only unread messages
CREATE INDEX idx_messages_unread ON messages(recipient_id) WHERE read_at IS NULL;
```

**Composite Indexes**
```sql
-- Multiple columns for common queries
CREATE INDEX idx_vote_records_vote_user ON vote_records(vote_id, user_id);
CREATE INDEX idx_user_roles_user_entity ON user_roles(user_id, entity_id);
```

---

## PART 5: MULTI-TENANCY SUPPORT

### Isolation Strategy

**Every Query Must Include Organization Context:**

```sql
-- Correct: Filtered by organization
SELECT * FROM votes WHERE entity_id = $1 AND status = 'active';

-- WRONG: Missing organization filter (security risk)
SELECT * FROM votes WHERE status = 'active';
```

**Application-Level Enforcement:**
```typescript
// Every query builder must include entity context
const votes = await db.votes
  .where({ entity_id: currentUser.entity_id, status: 'active' })
  .select();
```

**Row-Level Security (Future, Phase 2):**
```sql
-- PostgreSQL RLS policy
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY votes_isolation ON votes
  USING (entity_id = current_setting('app.entity_id')::uuid);
```

---

## PART 6: MULTI-COUNTRY SUPPORT

### Data Residency

**Country-Level Partitioning (Phase 2):**

```sql
-- Partition votes by country
CREATE TABLE votes_ng PARTITION OF votes
  FOR VALUES IN ('NG');

CREATE TABLE votes_ke PARTITION OF votes
  FOR VALUES IN ('KE');

-- ... more countries
```

**Regional Metadata:**
```sql
-- Store country in entity metadata
metadata: {
  "country": "NG",
  "state": "Lagos",
  "region": "Africa"
}
```

---

## PART 7: MIGRATION STRATEGY

### Version Control

**Migration Naming:**
```
migrations/
├── 001_initial_schema.sql          -- Bootstrap
├── 002_auth_tables.sql              -- Authentication
├── 003_governance_tables.sql        -- Voting
├── 004_add_audit_logging.sql        -- Audit trail
└── 005_optimize_indexes.sql         -- Performance
```

**Migration Format:**
```sql
-- 003_governance_tables.sql
-- Up migration
BEGIN;
  CREATE TABLE votes (...);
  CREATE TABLE vote_records (...);
  CREATE INDEX idx_votes_entity ON votes(entity_id);
COMMIT;

-- Down migration (rollback)
BEGIN;
  DROP INDEX IF EXISTS idx_votes_entity;
  DROP TABLE IF EXISTS vote_records;
  DROP TABLE IF EXISTS votes;
COMMIT;
```

### Migration Tool

**Recommended: Prisma Migrations or Flyway**
```bash
# Apply migrations
npm run db:migrate

# Rollback last migration
npm run db:migrate:rollback

# Create new migration
npm run db:migrate:create -- "add_new_feature"
```

---

## PART 8: BACKUP & DISASTER RECOVERY

### Backup Strategy

**Daily Snapshots:**
```bash
# AWS RDS automated backup
- Retention: 30 days
- Time: 2:00 AM UTC (off-peak)
- Multi-AZ: Cross-region backup
```

**Weekly Full Backups:**
```bash
aws rds create-db-snapshot \
  --db-instance-identifier vogg-prod \
  --db-snapshot-identifier vogg-prod-$(date +%Y-%m-%d)

# Upload to S3
aws s3 cp vogg-prod-backup.sql s3://vogg-backups/weekly/
```

**Monthly Archives:**
```bash
# Move to Glacier for compliance (7-year retention)
aws s3api put-object \
  --bucket vogg-backups \
  --key archive/$(date +%Y-%m)/backup.sql.gz \
  --storage-class GLACIER
```

### Recovery Procedures

**Point-in-Time Recovery (PITR):**
```bash
# Restore to specific timestamp
aws rds restore-db-instance-to-point-in-time \
  --source-db-instance-identifier vogg-prod \
  --target-db-instance-identifier vogg-prod-recovery \
  --restore-time 2025-06-26T12:00:00Z
```

**RTO/RPO Targets:**
- **RTO (Recovery Time Objective):** < 1 hour
- **RPO (Recovery Point Objective):** < 15 minutes

---

## PART 9: PERFORMANCE OPTIMIZATION

### Query Optimization

**Avoid N+1 Queries:**
```typescript
// Bad: N+1 problem
const votes = await db.votes.find({ entity_id });
for (const vote of votes) {
  vote.creator = await db.users.findById(vote.created_by);  // Loop!
}

// Good: JOIN or batch
const votes = await db.votes.find({ entity_id }).populate('creator');
```

**Pagination for Large Result Sets:**
```sql
-- Limit and offset
SELECT * FROM votes 
  WHERE entity_id = $1 
  ORDER BY created_at DESC 
  LIMIT 20 OFFSET 40;
```

**Denormalization (When Necessary):**
```sql
-- Cache vote count on entity
ALTER TABLE entities ADD COLUMN vote_count INT DEFAULT 0;

-- Update on vote creation via trigger
CREATE TRIGGER increment_vote_count
  AFTER INSERT ON votes
  FOR EACH ROW
  EXECUTE FUNCTION increment_entity_vote_count();
```

---

## PART 10: SECURITY CONSIDERATIONS

### Encryption at Rest

**PostgreSQL Native:**
```sql
-- Data encrypted with AWS managed keys
-- Configuration handled at RDS level
-- No application-level changes needed
```

### Encryption in Transit

**TLS 1.3+**
```bash
# Connection string
postgresql://user:password@host:5432/vogg?sslmode=require

# Verify
SELECT * FROM pg_stat_ssl;
```

### Field-Level Encryption (Phase 2)

```sql
-- Sensitive fields encrypted
-- Stored as bytea, decrypted on read
CREATE TABLE sensitive_data (
  id UUID PRIMARY KEY,
  encrypted_field BYTEA,  -- Encrypted with app key
  
  -- Searchable fields (not encrypted)
  email_hash VARCHAR(255)  -- Hash for uniqueness check
);
```

---

## PART 11: PRODUCTION DATABASE CHECKLIST

**Before Going Live:**

```
[ ] All migrations tested on staging
[ ] Indexes created and performance tested
[ ] Backup strategy verified (test restore)
[ ] RLS policies applied (if Phase 2)
[ ] Audit logging enabled
[ ] Connection pooling configured (PgBouncer)
[ ] Query monitoring enabled (pg_stat_statements)
[ ] Slow query logging configured
[ ] Replication set up (for high availability)
[ ] Failover tested
[ ] Encryption enabled
[ ] SSL certificates installed
[ ] Access restricted to application subnet
[ ] Regular maintenance jobs scheduled (VACUUM, ANALYZE)
[ ] Alerting configured for disk space, connections, locks
```

---

## APPENDIX: DDL SQL SCRIPT

```sql
-- VOGG Enterprise Database Schema (Complete)

BEGIN;

-- ============================================
-- CORE TABLES
-- ============================================

CREATE TABLE entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  slug VARCHAR(255) UNIQUE,
  metadata JSONB NOT NULL DEFAULT '{}',
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  verified_at TIMESTAMP,
  verification_level VARCHAR(20),
  parent_entity_id UUID REFERENCES entities(id),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMP,
  CONSTRAINT valid_type CHECK (type IN ('organization', 'government', 'ngo', 'company', 'religious', 'educational', 'investment', 'realtor', 'community')),
  CONSTRAINT valid_status CHECK (status IN ('active', 'suspended', 'archived'))
);

CREATE INDEX idx_entities_type ON entities(type);
CREATE INDEX idx_entities_status ON entities(status);
CREATE INDEX idx_entities_created_at ON entities(created_at);
CREATE INDEX idx_entities_parent ON entities(parent_entity_id);
CREATE INDEX idx_entities_metadata ON entities USING GIN(metadata);

-- ... [Continue with remaining tables] ...

COMMIT;
```

---

**Database Design Complete**  
**Version:** 1.0  
**Status:** ✅ Production-Ready  
**Date:** June 26, 2025

