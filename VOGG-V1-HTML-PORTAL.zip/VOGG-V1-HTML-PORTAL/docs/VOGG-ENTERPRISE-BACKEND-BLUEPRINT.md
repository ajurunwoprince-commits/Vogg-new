# VOGG ENTERPRISE BACKEND BLUEPRINT

**Date:** June 26, 2025 | **Version:** 1.0 | **Status:** ✅ Production-Ready

---

## PROJECT STRUCTURE

```
vogg-platform/
├── src/
│   ├── controllers/          # Request handlers
│   ├── services/             # Business logic
│   ├── repositories/         # Data access (Repository pattern)
│   ├── models/               # Data models/types
│   ├── middleware/           # Express middleware
│   ├── validators/           # Input validation
│   ├── utils/                # Helper functions
│   ├── config/               # Configuration
│   ├── types/                # TypeScript types
│   └── app.ts                # Express app setup
├── tests/
│   ├── unit/                 # Unit tests
│   ├── integration/          # Integration tests
│   └── fixtures/             # Test data
├── migrations/               # Database migrations
├── .env.example              # Environment template
├── .env.local                # Local (gitignored)
├── docker-compose.yml        # Local environment
├── Dockerfile                # Production image
├── package.json
├── tsconfig.json
├── jest.config.js
└── README.md
```

---

## CORE MODULES

### 1. Authentication Module

**Responsibilities:**
- User registration & email verification
- Login/logout
- JWT token generation & refresh
- Password reset

**Key Files:**
```
src/
├── controllers/auth.controller.ts
├── services/auth.service.ts
├── middleware/auth.middleware.ts
└── validators/auth.validator.ts
```

**Implementation:**
```typescript
// services/auth.service.ts
class AuthService {
  async register(email, password, profile)
  async login(email, password)
  async refreshToken(refreshToken)
  async logout(userId)
  async resetPassword(email)
}
```

---

### 2. Entity Module (Organizations)

**Responsibilities:**
- Create/read/update/delete organizations
- Entity relationships
- Metadata management

**Structure:**
```
src/
├── controllers/entity.controller.ts
├── services/entity.service.ts
├── repositories/entity.repository.ts
└── validators/entity.validator.ts
```

---

### 3. Governance Module (MVP Core)

**Responsibilities:**
- Vote creation & management
- Vote casting
- Results calculation
- Verification

**Key Classes:**
```typescript
class VoteService {
  async createVote(entityId, voteData)
  async castVote(voteId, userId, choice)
  async getResults(voteId)
  async validateVoter(voteId, userId)
}
```

---

### 4. User Management Module

**Responsibilities:**
- User profiles
- Organization membership
- Role assignment

---

### 5. Notification Module

**Responsibilities:**
- Email sending
- SMS (future)
- Push notifications
- In-app notifications

**Pattern:**
```typescript
// Job-based async notification
const notificationQueue = new Queue('notifications');

notificationQueue.on('vote:ended', async (data) => {
  await emailService.sendVoteEnded(data);
});
```

---

## ARCHITECTURE PATTERNS

### Repository Pattern

```typescript
// repositories/vote.repository.ts
class VoteRepository {
  async findById(id)
  async findByEntity(entityId)
  async create(data)
  async update(id, data)
  async delete(id)
}

// services/vote.service.ts
class VoteService {
  constructor(private voteRepository: VoteRepository) {}
  
  async createVote(data) {
    return this.voteRepository.create(data);
  }
}
```

### Dependency Injection

```typescript
// Use tsyringe or similar
@injectable()
class VoteService {
  constructor(
    @inject('VoteRepository') private repo: VoteRepository,
    @inject('NotificationService') private notify: NotificationService
  ) {}
}
```

### Middleware Stack

```typescript
app.use(express.json());
app.use(cors());
app.use(requestLogger);
app.use(authMiddleware);
app.use(rbacMiddleware);
app.use(errorHandler);
```

---

## ERROR HANDLING

```typescript
// utils/errors.ts
class AppError extends Error {
  constructor(
    public code: string,
    public httpStatus: number,
    message: string
  ) {
    super(message);
  }
}

// Throw in service
throw new AppError('INVALID_INPUT', 400, 'Email is required');

// Catch in middleware
app.use((err, req, res, next) => {
  res.status(err.httpStatus || 500).json({
    success: false,
    error: { code: err.code, message: err.message }
  });
});
```

---

## VALIDATION FRAMEWORK

```typescript
// validators/entity.validator.ts
const createEntitySchema = z.object({
  name: z.string().min(1).max(255),
  type: z.enum(['organization', 'government', ...]),
  metadata: z.object({}).optional()
});

// In controller
const data = createEntitySchema.parse(req.body);
```

---

## TESTING STRATEGY

**Unit Tests (80%+ coverage):**
```typescript
describe('VoteService', () => {
  it('should create vote with valid data', async () => {
    const result = await service.createVote(testData);
    expect(result.id).toBeDefined();
  });
});
```

**Integration Tests:**
```typescript
describe('POST /votes', () => {
  it('should create vote and return 201', async () => {
    const res = await request(app)
      .post('/votes')
      .set('Authorization', `Bearer ${token}`)
      .send(testData);
    expect(res.status).toBe(201);
  });
});
```

---

## LOGGING & MONITORING

```typescript
// utils/logger.ts
const logger = winston.createLogger({
  transports: [
    new transports.Console(),
    new transports.File({ filename: 'error.log', level: 'error' }),
    new transports.File({ filename: 'combined.log' })
  ]
});

// Usage
logger.info('User registered', { userId, email });
logger.error('Vote failed', { voteId, error });
```

---

## CODING STANDARDS

**TypeScript:**
- Strict mode enabled
- Explicit types (no `any`)
- Interfaces for contracts

**Naming:**
- camelCase for variables/functions
- PascalCase for classes/interfaces
- UPPER_SNAKE_CASE for constants

**File Organization:**
- One class per file
- Organized by domain (auth/, entities/, votes/)
- Tests colocated with source

---

**Backend Blueprint Complete**  
**Status:** ✅ Ready for Implementation

