# Security Policy

## Reporting Vulnerabilities

If you discover a security vulnerability:

1. **Do NOT create a public GitHub issue**
2. Contact the security team immediately
3. Include vulnerability description and affected component
4. Include reproduction steps (if applicable)

## Security Standards

VOGG implements:

- JWT authentication (RS256)
- Role-based access control (RBAC)
- AES-256 encryption for sensitive data
- TLS 1.3 for all transport
- bcrypt password hashing (12 rounds)
- Static analysis scanning (SAST)
- Dependency vulnerability scanning
- Code review with security focus
- Penetration testing before production

## Dependencies

See documentation for complete dependency list with:
- License information
- Vulnerability tracking
- Update procedures

## Compliance

- GDPR compliant
- CCPA compliant
- Regular security audits
- Incident response procedures

---

Security is a shared responsibility.
