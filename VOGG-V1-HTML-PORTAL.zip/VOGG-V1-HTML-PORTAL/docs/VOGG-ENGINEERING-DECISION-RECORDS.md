# VOGG ENGINEERING DECISION RECORDS (ADRs)

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Final  
**Purpose:** Document critical technical decisions and their rationale  

---

## ADR-001: Universal Organization Model with JSONB Metadata

**Status:** APPROVED  
**Date:** June 2025  

### Problem

VOGG needs to support organizations across 7+ sectors (governance, religious, education, business, real estate, investment, community) and potentially 100+ sub-categories without requiring schema changes for each sector.

**Initial Approach Considered:**
- Option A: Separate table per sector (governance_orgs, business_orgs, etc.)
  - ❌ Not scalable (adds tables with each sector)
  - ❌ Code duplication
  - ❌ Shared logic becomes complex

- Option B: Universal entity table with JSONB metadata
  - ✅ Single schema
  - ✅ Extensible without migrations
  - ✅ Flexible per-sector data
  - ✅ Standard relationships

### Decision

**Implement Option B: Universal `entities` table with JSONB metadata**

```sql
CREATE TABLE entities (
  id UUID PRIMARY KEY,
  type VARCHAR(50),              -- 'organization', 'government', etc.
  name VARCHAR(255),
  metadata JSONB,                -- { "sector": "governance", "country": "NG" }
  status VARCHAR(20),
  createdAt TIMESTAMP,
  updatedAt TIMESTAMP
);
```

### Rationale

1. **Scalability:** Add sectors via config, not code
2. **Performance:** Single table with indexes is faster than JOINs
3. **Flexibility:** Each sector defines its own metadata schema
4. **Migration:** No database schema changes needed for new sectors
5. **Query:** Single index on type covers most queries

### Consequences

- **Positive:**
  - Can support unlimited sectors
  - Metadata is completely flexible
  - Single codebase for all sectors

- **Negative:**
  - JSONB queries require PostgreSQL-specific syntax
  - No type checking on metadata at database level
  - Must enforce schema at application level

### Implementation

- Metadata schema defined in `/docs/metadata-schemas/`
- Validation at application layer (Zod schemas)
- Indexes on `type` and `metadata->>'sector'`

### Review Criteria

Re-evaluate if:
- New sector requires > 10 new columns
- Performance degrades (query time > 100ms)
- JSONB becomes > 10KB per record

---

## ADR-002: JWT-Based Authentication vs. Session-Based

**Status:** APPROVED  
**Date:** June 2025

### Problem

Need stateless authentication that works for:
- Single-page applications (SPA)
- Mobile applications (future)
- Third-party integrations (future)
- Distributed systems (future)

### Options Considered

**Option A: Session-Based (Traditional)**
- Store sessions in database
- Return session ID to client
- Validate on every request

**Option B: JWT-Based (Stateless)**
- Sign token with secret
- Client stores token
- Validate signature on every request
- No server-side state

### Decision

**Implement JWT-Based Authentication**

```
Login Flow:
User → POST /auth/login → Verify credentials → 
Issue accessToken (15 min) + refreshToken (7 days) →
Client stores tokens → Requests use Authorization header

Token Refresh Flow:
accessToken expires → POST /auth/refresh with refreshToken →
Issue new accessToken → Continue with new token
```

### Rationale

1. **Stateless:** Scale to multiple backend servers
2. **Mobile-Ready:** Works with native apps
3. **Third-Party:** Can issue tokens for integrations
4. **Performance:** No database lookup per request (just signature verification)
5. **Standard:** OpenID/OAuth compatible

### Consequences

- **Positive:**
  - Horizontally scalable
  - Mobile-friendly
  - Integration-ready
  - Better performance

- **Negative:**
  - Cannot immediately revoke (token valid until expiry)
  - Token size larger than session ID
  - Client-side storage security required

### Implementation

- Library: jsonwebtoken (Node.js)
- Signing algorithm: RS256 (asymmetric)
- Claims: sub, email, roles, organizationId, iat, exp
- Secret stored in AWS Secrets Manager
- Access token: 15 minutes
- Refresh token: 7 days (longer duration, refresh only)

### Mitigation for Revocation

- Short-lived access tokens (15 min)
- Refresh token blacklist in Redis (if immediate revocation needed)
- Add `jti` (JWT ID) claim for tracking

### Review Criteria

Re-evaluate if:
- Token size > 5KB becomes performance issue
- Revocation requirement becomes critical
- Authentication becomes stateful requirement

---

## ADR-003: PostgreSQL + Redis Architecture

**Status:** APPROVED  
**Date:** June 2025

### Problem

Need to support:
- Persistent data (organizations, votes, users)
- Session management
- Caching for performance
- Real-time features (future)
- Queue processing (future)

### Options Considered

**Option A: Single Database (PostgreSQL only)**
- ✅ Simple architecture
- ❌ No caching layer
- ❌ Slower for high-traffic
- ❌ No session management

**Option B: PostgreSQL + Redis**
- ✅ Persistent + Caching
- ✅ Session management
- ✅ Queue capability
- ✅ Real-time features

**Option C: MongoDB + Redis**
- ✅ Flexible schema
- ❌ ACID compliance weaker
- ❌ Voting data needs ACID
- ❌ Not VOGG's constraint

### Decision

**PostgreSQL (persistent) + Redis (session/cache)**

```
Architecture:
┌─────────────┐
│   Client    │
└──────┬──────┘
       │
┌──────▼──────────┐
│   API Server    │
├──────┬──────────┤
│ PG   │  Redis   │
└──────┴──────────┘

Data Distribution:
- PostgreSQL: Organizations, votes, users, audit logs
- Redis: Sessions, cache, rate limiting, queues
```

### Rationale

1. **Persistence:** PostgreSQL ACID for votes (critical data)
2. **Performance:** Redis cache eliminates database queries
3. **Sessions:** Redis manages sessions efficiently
4. **Queue Ready:** Redis Bull/BullMQ for async jobs
5. **Proven:** Industry standard stack

### Consequences

- **Positive:**
  - Fast response times (cache hit)
  - Session management built-in
  - Ready for async processing
  - ACID guarantees for votes

- **Negative:**
  - Cache consistency requires care
  - Two systems to manage
  - Invalidation complexity

### Implementation

- PostgreSQL 15+ (primary data)
- Redis 7+ (session + cache + queue)
- Cache TTL: 5 minutes (default)
- Session store: Redis
- Queue: Bull (Node.js)

### Cache Strategy

```
Vote data: 1 hour TTL
Organization data: 30 min TTL
User profile: 5 min TTL
Results: No cache (always fresh until closed)
```

### Review Criteria

Re-evaluate if:
- Cache hit rate < 50%
- Database response time > 100ms
- Session count > 100K concurrent

---

## ADR-004: Monolith with Service Boundaries (Ready for Microservices)

**Status:** APPROVED  
**Date:** June 2025

### Problem

Need architecture that:
- Works as single application (MVP)
- Scales to microservices (Phase 2+)
- Clear service boundaries
- Independent testing

### Options Considered

**Option A: Microservices from Day 1**
- ✅ Scalable
- ❌ Complex
- ❌ Slow to develop
- ❌ Operational overhead

**Option B: Monolith with Service Boundaries**
- ✅ Simple to develop
- ✅ Clear structure
- ✅ Easy to test
- ✅ Can become microservices

### Decision

**Monolith with clear service boundaries**

```
Project Structure:
src/
├── modules/
│   ├── auth/                 ← Auth Service
│   ├── users/                ← User Service
│   ├── organizations/        ← Org Service
│   ├── governance/           ← Governance Service
│   ├── notifications/        ← Notification Service
│   └── analytics/            ← Analytics Service
├── shared/
│   ├── types/
│   ├── decorators/
│   ├── guards/
│   └── middleware/
└── app.ts
```

**Each module is a potential microservice:**
```
Future Microservices:
auth → @vogg/auth-service
governance → @vogg/governance-service
notifications → @vogg/notification-service
etc.
```

### Rationale

1. **MVP Speed:** Single deployment, single database
2. **Clarity:** Module structure defines future services
3. **Testing:** Modules independently testable
4. **Migration:** Can split to microservices incrementally
5. **Complexity:** Appropriate for stage

### Consequences

- **Positive:**
  - Fast development
  - Simple deployment
  - Clear boundaries for future split
  - Easy debugging

- **Negative:**
  - Scaling limited by monolith limits
  - Database shared (becomes bottleneck)
  - Deployment couples all modules

### Implementation

- Modules have:
  - controllers/ (HTTP handlers)
  - services/ (business logic)
  - repositories/ (data access)
  - types/ (domain models)
  - index.ts (exports)

- Strict rules:
  - No cross-module imports except via /api routes
  - Each module has own database queries
  - Dependencies injected
  - Clear interfaces between modules

### Migration Path to Microservices

**When to Split:**
- Module needs different scaling
- Module has different deployment cycle
- Module needs separate data store
- Operational complexity requires isolation

**Steps:**
1. Extract module to separate process
2. Create API gateway for routing
3. Replicate database (with sync)
4. Move async jobs to separate service

### Review Criteria

Re-evaluate if:
- Single module consuming > 50% resources
- Deployment frequency needed > 1/day
- Data isolation required between modules

---

## ADR-005: API Versioning Strategy

**Status:** APPROVED  
**Date:** June 2025

### Problem

Need API versioning that:
- Supports evolution without breaking clients
- Clear upgrade path
- Multiple versions live
- Deprecation timeline

### Strategy

**URL Path Versioning: `/api/v1/`, `/api/v2/`, etc.**

```
Current: /api/v1/votes
Future:  /api/v2/votes (if breaking changes)
Sunset:  /api/v1/ deprecated, removed after 6 months
```

### Rules

1. **Within Version:** No breaking changes
   - Add endpoints: OK
   - Add optional fields: OK
   - Remove fields: NOT OK
   - Change behavior: NOT OK

2. **New Version Required When:**
   - Field removed
   - Behavior changes
   - Response format changes
   - Permission changes

3. **Deprecation Timeline:**
   - Announce 6 months ahead
   - Provide migration guide
   - Sunset header: `Sunset: Sun, 26 Jun 2026 23:59:59 GMT`
   - Remove after timeline expires

### Response Format

```
HTTP/1.1 200 OK
Sunset: Sun, 26 Jun 2026 23:59:59 GMT
Deprecation: true

{
  "success": true,
  "data": { ... },
  "meta": { "version": "1.0" }
}
```

### Implementation

- Version in URL path (not header)
- Default to latest
- All versions in parallel
- Version-specific routers

---

## Summary of Decisions

| Decision | Status | Date |
|----------|--------|------|
| Universal Organization Model | ✅ APPROVED | Jun 2025 |
| JWT Authentication | ✅ APPROVED | Jun 2025 |
| PostgreSQL + Redis | ✅ APPROVED | Jun 2025 |
| Monolith with Service Boundaries | ✅ APPROVED | Jun 2025 |
| URL Path Versioning | ✅ APPROVED | Jun 2025 |

---

**ADRs Complete**  
**Status:** ✅ Technical decisions documented and ratified

