# VOGG Platform - Quick Start Guide

## ⚡ 30-Second Setup

**Option 1: Open Directly (Easiest)**
```bash
# Double-click index.html to open in your browser
# That's it! Platform is ready to use
```

**Option 2: Run Local Server**
```bash
# macOS/Linux
python3 -m http.server 8000

# Windows (Command Prompt)
python -m http.server 8000

# Then open: http://localhost:8000
```

**Option 3: Node.js**
```bash
npx http-server
# Opens at: http://localhost:8080
```

---

## 🎯 First Steps

1. **Open the platform** → See home page with overview
2. **Click sidebar items** → Navigate between modules
3. **Try search bar** → Search for anything (demo feature)
4. **Check mobile view** → Resize browser or test on phone

---

## 📚 Module Quick Links

| Module | What It Shows |
|--------|--------------|
| 🏠 **Home** | Platform overview & stats |
| 🏛️ **Government** | Executive performance metrics |
| ⚖️ **Parliament** | Bills & legislative activity |
| ⚔️ **Judiciary** | Court system & cases |
| 👥 **Community** | Civic engagement & discussions |
| 🏢 **Institutions** | Institutional framework |
| 🌍 **Country** | National governance dashboard |
| 🗺️ **Rivers State** | State-level metrics |
| 🌏 **Africa Map** | Continental data |
| 🌐 **World Map** | Global comparison |
| 📊 **Economic** | Economic indicators |
| 💼 **Investment** | Investment opportunities |
| 🎯 **Opportunities** | Growth opportunities |

---

## 🔧 Customization Tips

### Change Colors
Edit line 20-40 in `index.html`:
```css
:root {
    --gold: #0090e8;     /* Change this to any color */
    --em: #5cc928;       /* Change this too */
}
```

### Change Logo Text
Find line ~350:
```html
<div class="logo-text-main">VOGG</div>
```
Change "VOGG" to your text.

### Add New Module
1. Add to sidebar (around line ~430)
2. Add to modules object (around line ~700)
3. Follow the template from existing modules

---

## 📱 Mobile Testing

**Desktop Browser:**
- Press F12 → Toggle device toolbar → Select mobile device
- Test at 375px (iPhone), 768px (iPad), 1024px (Desktop)

**Real Device:**
- If using local server: Find your computer's IP
- Open: http://[your-ip]:8000 on mobile
- Test navigation, sidebar, buttons

---

## ⚙️ Performance

- **File Size:** ~73 KB
- **Load Time:** <1 second
- **No external dependencies**
- **Works offline** (after first load)
- **Mobile optimized**

---

## 🚀 Going Live

**Easiest:** Drag & drop to Netlify.com
**Quick:** Upload to GitHub, enable Pages
**Secure:** Deploy to web server with HTTPS

See `DEPLOYMENT.md` for detailed options.

---

## ❓ FAQ

**Q: Can I use this offline?**  
A: Yes! Once loaded, it works without internet (except search/API features).

**Q: How do I add real data?**  
A: Replace dummy data in module functions with API calls to your backend.

**Q: Can I change the theme?**  
A: Yes! Edit CSS variables in the `<style>` section.

**Q: Is it mobile-friendly?**  
A: Absolutely! Test by resizing browser or opening on phone.

**Q: How do I add authentication?**  
A: Add login page before app initialization, store token in localStorage.

**Q: Can I add more modules?**  
A: Yes! Follow the pattern from existing modules.

---

## 🎨 Design Elements

### Colors
- Primary Blue: `#0090e8`
- Accent Green: `#5cc928`
- Dark Background: `#080c18`
- Light Text: `#f0ede6`

### Buttons
```html
<button class="btn btn-primary">Primary Button</button>
<button class="btn btn-secondary">Secondary Button</button>
<button class="btn btn-outline">Outline Button</button>
```

### Cards & Badges
```html
<div class="module-card">Content here</div>
<span class="badge badge-success">Success</span>
<span class="badge badge-warning">Warning</span>
<span class="badge badge-error">Error</span>
<span class="badge badge-info">Info</span>
```

---

## 📊 Sample Data Structure

```javascript
// Adding real data to modules:
modules: {
    government() {
        return `
            <div class="dashboard-grid">
                <div class="stat-card">
                    <div class="stat-value">${data.transparency}</div>
                    <div class="stat-label">Transparency Score</div>
                </div>
            </div>
        `;
    }
}
```

---

## 🐛 Troubleshooting

**Sidebar not working?**
- Clear browser cache: Ctrl+Shift+Delete
- Try different browser
- Check JavaScript console (F12 → Console tab)

**Styles look wrong?**
- Make sure CSS is loading (F12 → Network tab)
- Try hard refresh: Ctrl+Shift+R
- Check browser zoom level

**Search not working?**
- Search is a placeholder feature
- To enable: Connect to backend API
- Or implement local search functionality

**Mobile layout broken?**
- Check viewport meta tag is present
- Test with real mobile device
- Verify CSS media queries

---

## 📞 Support

**Questions?** Check README.md  
**Deploy help?** See DEPLOYMENT.md  
**Need to modify?** Edit index.html directly

---

## 🎓 Learning Resources

**HTML/CSS/JavaScript:**
- [MDN Web Docs](https://developer.mozilla.org)
- [CSS-Tricks](https://css-tricks.com)
- [JavaScript.info](https://javascript.info)

**Web Development:**
- [freeCodeCamp](https://freecodecamp.org)
- [Codecademy](https://codecademy.com)
- [Coursera](https://coursera.org)

---

## ✅ Checklist Before Going Live

- [ ] Tested on desktop browsers
- [ ] Tested on mobile devices
- [ ] All links working
- [ ] Search/API features (if needed) configured
- [ ] Contact information updated
- [ ] Backed up files
- [ ] Domain configured (if using)
- [ ] HTTPS enabled
- [ ] Analytics setup (if needed)
- [ ] Monitoring configured
- [ ] README updated with your info

---

**Ready to go?** Open `index.html` and start exploring! 🚀

**Built with ❤️ for Africa's Digital Future**
