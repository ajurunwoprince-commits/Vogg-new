# VOGG FUNCTIONAL REQUIREMENTS SPECIFICATION (FRS)

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Final  
**Purpose:** Complete functional specification for MVP implementation  
**Author:** Chief Software Architect  

---

## DOCUMENT STRUCTURE

This FRS defines all functional requirements for VOGG modules in a format engineers can directly implement against.

Every requirement includes:
- Clear acceptance criteria
- Business rules
- Validation rules
- Exceptions
- Data entities

---

## PART 1: GOVERNANCE MODULE (MVP CORE)

### 1.1 Module Purpose

The Governance Module enables organizations to facilitate democratic participation, transparent voting, and collaborative decision-making.

**Scope:** Phase 1 (MVP)

**Target User:** Organization members voting on organizational matters

---

### 1.2 Actors

| Actor | Definition |
|-------|-----------|
| **Administrator** | Organization leader with full permissions |
| **Creator** | Member who creates votes/proposals |
| **Voter** | Verified member eligible to vote |
| **Auditor** | External viewer with read-only access |

---

### 1.3 Key Entities

```
Entity: Vote
├─ id (UUID)
├─ organizationId (UUID, FK)
├─ title (string, required, max 255)
├─ description (text, optional)
├─ voteType (enum: single_choice, multiple_choice, ranked)
├─ options (JSON array)
├─ eligibilityCriteria (JSON object)
├─ status (enum: draft, active, closed, cancelled)
├─ createdBy (UUID, FK to User)
├─ createdAt (timestamp)
├─ startsAt (timestamp, required)
├─ endsAt (timestamp, required)
├─ results (JSON object)
├─ participantCount (integer)
├─ publicVisibility (boolean)
└─ metadata (JSONB)

Entity: Vote_Record
├─ id (UUID)
├─ voteId (UUID, FK)
├─ userId (UUID, FK)
├─ choice (string)
├─ votedAt (timestamp)
├─ ipAddress (string, for audit)
└─ UNIQUE(voteId, userId) → Prevents duplicate votes
```

---

### 1.4 Core Workflows

#### Workflow 1: Create Vote

**Actor:** Creator or Administrator  
**Trigger:** Creator submits vote creation form  
**Precondition:** User has `vote:create` permission in organization

**Steps:**

1. User submits:
   - Title (required, 1-255 characters)
   - Description (optional)
   - Vote type (single_choice | multiple_choice | ranked)
   - Options (2-50 options)
   - Start time (required, >= current time)
   - End time (required, > start time)
   - Eligibility criteria (optional)

2. System validates:
   - Title is not empty
   - Options count is valid (2-50)
   - Start < End time
   - Eligibility criteria format is valid (if provided)

3. System creates vote with status: `draft`

4. System returns:
   - Vote ID
   - Vote details
   - Edit link

**Acceptance Criteria:**
- ✅ Draft vote created in database
- ✅ Vote has status='draft'
- ✅ Only creator and org admins can edit
- ✅ Vote not visible to organization until published

**Business Rules:**
- Votes cannot be created with start time in past
- Maximum 50 options per vote
- Title must be unique within organization (per month)
- Only organization members can create votes

---

#### Workflow 2: Publish Vote

**Actor:** Creator or Administrator  
**Trigger:** Creator clicks "Publish" button  
**Precondition:** Vote status is `draft`

**Steps:**

1. User clicks "Publish Vote" on draft vote

2. System validates:
   - Vote is in draft status
   - Current time < vote start time
   - At least 2 options exist
   - Title and description populated

3. System changes status: `draft` → `active`

4. System records:
   - Who published it
   - When it was published
   - Eligible voter count (snapshot)

5. System notifies:
   - All eligible voters
   - Organization leadership

**Acceptance Criteria:**
- ✅ Vote status changes to 'active'
- ✅ Vote becomes visible to all organization members
- ✅ Voting becomes enabled
- ✅ Change recorded in audit log

**Business Rules:**
- Published votes cannot be edited
- Published votes cannot be deleted
- Voting starts at scheduled start time (not immediately)
- Notifications sent immediately

---

#### Workflow 3: Cast Vote

**Actor:** Voter  
**Trigger:** Voter selects option and submits  
**Precondition:** 
- Vote status is `active`
- Current time >= vote start time
- Current time <= vote end time
- User meets eligibility criteria

**Steps:**

1. User selects one or more options based on vote type:
   - Single choice: Select 1 option
   - Multiple choice: Select 1+ options
   - Ranked: Rank all options

2. System validates:
   - User is organization member
   - User meets eligibility criteria
   - Current time within voting window
   - User has not already voted

3. System records vote_record with:
   - vote_id
   - user_id
   - choice (or choices)
   - voted_at (timestamp)
   - ip_address (for audit)

4. System increments vote count

5. System returns confirmation

**Acceptance Criteria:**
- ✅ Vote recorded in database
- ✅ User cannot vote again on same vote
- ✅ Vote count incremented
- ✅ Vote appears in real-time results
- ✅ Audit log entry created

**Business Rules:**
- One vote per user per vote (enforced by database UNIQUE constraint)
- Votes cannot be modified after submission
- Voting requires active session
- IP logging for fraud detection

---

#### Workflow 4: Close Vote (Automatic)

**Actor:** System  
**Trigger:** Vote end time reached  
**Precondition:** Vote status is `active`

**Steps:**

1. Scheduled job checks all active votes at end time

2. For each expired vote:
   - Change status: `active` → `closed`
   - Calculate results
   - Record closed timestamp
   - Create audit entry

3. Calculate results:
   - Single choice: Count votes for each option
   - Multiple choice: Count votes per option
   - Ranked: Apply Borda count

4. Notify:
   - Organization
   - Voting participants
   - Leadership team

**Acceptance Criteria:**
- ✅ Vote automatically closes at end time
- ✅ Results calculated accurately
- ✅ Status changes to 'closed'
- ✅ No new votes accepted after close time

**Business Rules:**
- Results visible only after vote closes
- Closing is irreversible
- Results are final and unchangeable
- Notification sent within 5 minutes of close

---

### 1.5 Permissions Model (RBAC)

```
Role: administrator
├─ vote:create
├─ vote:edit (draft only)
├─ vote:delete (draft only)
├─ vote:publish
├─ vote:close
├─ vote:view_results (including interim)
├─ vote:view_audit
└─ user:manage

Role: moderator
├─ vote:create
├─ vote:publish
├─ vote:view_results
└─ vote:view_audit

Role: member
├─ vote:create
├─ vote:view
├─ vote:vote (if eligible)
└─ vote:view_results

Role: viewer
├─ vote:view
└─ vote:view_results (only closed votes)

Role: pending
└─ (no permissions until verified)
```

---

### 1.6 Business Rules

| Rule | Definition | Enforcement |
|------|-----------|------------|
| **Unique Vote** | User can vote once per vote | Database UNIQUE(vote_id, user_id) |
| **Timing** | Voting only during active window | Application + database timestamp check |
| **Eligibility** | Only eligible members vote | RBAC + eligibility criteria check |
| **Immutability** | Closed votes unchangeable | Status-based query restriction |
| **Transparency** | Results visible after close | Status-based permission check |
| **Audit Trail** | All changes logged | Trigger on every modification |

---

### 1.7 Validation Rules

**Vote Creation:**
```
title:
  - Required
  - Length: 1-255 characters
  - No HTML/script tags
  
description:
  - Optional
  - Max 5000 characters
  - No HTML/script tags
  
voteType:
  - Enum: single_choice | multiple_choice | ranked
  
options:
  - Array of 2-50 items
  - Each 1-255 characters
  - No duplicates
  - No empty strings
  
startTime:
  - Required
  - >= current time
  - ISO 8601 format
  
endTime:
  - Required
  - > startTime
  - ISO 8601 format
  
eligibilityCriteria:
  - Optional
  - Valid JSON schema
  - Supports: role, verificationLevel, joinDate
```

---

### 1.8 Data Validation Rules

**Vote Casting:**
```
choice (single_choice):
  - Required
  - Must match one of vote options
  - String, max 255 chars
  
choices (multiple_choice):
  - Required
  - Array of 1+ items
  - Each must match vote option
  - Max same as vote option count
  
ranking (ranked):
  - Required
  - Array of all options in order
  - Each option appears exactly once
```

---

### 1.9 Exception Handling

| Exception | Cause | Response |
|-----------|-------|----------|
| **InvalidVoteType** | Unknown vote type | 400 Bad Request + error message |
| **InvalidTimeWindow** | End time <= start time | 400 Bad Request |
| **DuplicateVote** | User already voted | 409 Conflict |
| **VoteNotActive** | Voting window closed | 410 Gone |
| **IneligibleVoter** | User doesn't meet criteria | 403 Forbidden |
| **NotFound** | Vote doesn't exist | 404 Not Found |
| **Unauthorized** | User lacks permission | 401 Unauthorized |

---

### 1.10 Acceptance Criteria (Module Complete)

**API Endpoints Exist:**
- ✅ POST /governance/votes (create)
- ✅ POST /governance/votes/{id}/publish (publish)
- ✅ POST /governance/votes/{id}/vote (cast vote)
- ✅ GET /governance/votes (list)
- ✅ GET /governance/votes/{id} (details)
- ✅ GET /governance/votes/{id}/results (results)
- ✅ GET /governance/votes/{id}/audit (audit trail)

**Database Persists:**
- ✅ Votes stored in PostgreSQL
- ✅ Vote records stored
- ✅ Audit entries created
- ✅ Relationships maintained

**Tests Pass:**
- ✅ Create draft vote
- ✅ Publish vote
- ✅ Cast vote
- ✅ Prevent duplicate vote
- ✅ Prevent vote after end time
- ✅ Calculate results correctly
- ✅ Permission checks enforced

**Validation Works:**
- ✅ Invalid data rejected
- ✅ Errors reported clearly
- ✅ Business rules enforced

---

## PART 2: AUTHENTICATION MODULE

### 2.1 Module Purpose

Authenticate users and manage sessions securely.

---

### 2.2 Key Workflows

#### Workflow: Register User

**Precondition:** User not yet registered

**Steps:**
1. User submits email, password, profile
2. System validates email format and strength
3. System hashes password (bcrypt, 12 rounds)
4. System creates user record
5. System sends verification email
6. System returns user ID

**Acceptance Criteria:**
- ✅ User stored in database
- ✅ Password hashed (never in plaintext)
- ✅ Verification email sent
- ✅ User status = 'pending' until verified

**Validation Rules:**
```
email:
  - Required
  - Valid email format
  - Unique in system
  
password:
  - Required
  - Minimum 12 characters
  - Must include uppercase, lowercase, number, special char
  - Cannot contain email
  
profile:
  - firstName: 1-100 characters
  - lastName: 1-100 characters
```

---

#### Workflow: Login

**Precondition:** User registered and verified

**Steps:**
1. User submits email, password
2. System finds user by email
3. System compares password with hash
4. System verifies user is active
5. System generates JWT token
6. System returns token + refresh token

**Acceptance Criteria:**
- ✅ JWT issued with correct expiry
- ✅ Refresh token issued
- ✅ Session created
- ✅ Login recorded in audit

**Business Rules:**
- Failed login attempts tracked (max 5 per hour)
- Account locked after 5 failed attempts (1 hour)
- JWT expires in 15 minutes
- Refresh token expires in 7 days

---

### 2.3 Permission Model (RBAC)

```
Permissions:
  - user:read (own profile)
  - user:update (own profile)
  - user:delete (own account)
  - organization:create
  - organization:read
  - organization:update (admin only)
```

---

## PART 3: ORGANIZATION MODULE

### 3.1 Module Purpose

Manage organizations, members, and roles.

---

### 3.2 Key Entities

```
Entity: Organization
├─ id (UUID)
├─ name (string, required)
├─ description (text)
├─ type (enum: nonprofit, government, business, etc.)
├─ status (enum: active, suspended)
├─ createdBy (UUID, FK)
├─ createdAt (timestamp)
└─ metadata (JSONB)

Entity: Membership
├─ userId (UUID, FK)
├─ organizationId (UUID, FK)
├─ role (enum: admin, moderator, member, viewer)
├─ joinedAt (timestamp)
└─ PRIMARY KEY (userId, organizationId)

Entity: Role
├─ id (UUID)
├─ organizationId (UUID, FK)
├─ name (string)
├─ permissions (JSON array)
└─ createdAt (timestamp)
```

---

### 3.3 Core Workflows

#### Workflow: Create Organization

**Actor:** Authenticated user

**Steps:**
1. User submits org name, type, description
2. System validates input
3. System creates organization
4. System adds creator as admin
5. System returns org ID

**Acceptance Criteria:**
- ✅ Organization created in database
- ✅ Creator has admin role
- ✅ Org ID returned

---

#### Workflow: Add Member

**Actor:** Organization admin

**Steps:**
1. Admin submits member email
2. System finds user by email
3. System adds to membership
4. System sends notification
5. System returns confirmation

**Acceptance Criteria:**
- ✅ User added to organization
- ✅ User assigned default role
- ✅ Notification sent
- ✅ Audit entry created

---

## PART 4: USER MODULE

### 4.1 Module Purpose

Manage user profiles and settings.

---

### 4.2 Key Workflows

#### Workflow: Update Profile

**Precondition:** User authenticated

**Steps:**
1. User submits profile changes
2. System validates
3. System updates record
4. System returns updated profile

**Validation Rules:**
```
firstName, lastName: 1-100 chars each
email: Valid format, not already used
avatar: URL format if provided
```

---

## ACCEPTANCE CRITERIA SUMMARY

### For MVP Completion, These Must Work:

**Authentication Module:**
- ✅ Register user
- ✅ Verify email
- ✅ Login user
- ✅ Receive JWT
- ✅ Refresh token
- ✅ Logout

**Organization Module:**
- ✅ Create organization
- ✅ Add member
- ✅ Assign role
- ✅ Update organization
- ✅ List organizations

**Governance Module:**
- ✅ Create vote (draft)
- ✅ Publish vote
- ✅ Cast vote
- ✅ View results
- ✅ Close vote (automatic)
- ✅ View audit

**User Module:**
- ✅ Get profile
- ✅ Update profile

**Cross-Cutting:**
- ✅ All endpoints require authentication
- ✅ All changes logged to audit
- ✅ All errors return proper HTTP status
- ✅ All validation enforced
- ✅ RBAC enforced on every endpoint

---

**FRS Complete**  
**Status:** ✅ Ready for Implementation  
**Next:** PRD + Module Specifications

