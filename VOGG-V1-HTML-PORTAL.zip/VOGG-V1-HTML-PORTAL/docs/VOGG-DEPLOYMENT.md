# VOGG Platform - Deployment Guide

## 🚀 Production Deployment

### Prerequisites
- Web hosting (shared, VPS, cloud platform)
- Domain name (optional but recommended)
- SSL certificate (HTTPS)
- Basic server administration knowledge

---

## Deployment Methods

### 1. Netlify (Recommended - Free Tier)

**Pros:** Free, auto-HTTPS, global CDN, easy deploy  
**Cons:** Limited to 100GB/month bandwidth

**Steps:**
1. Go to [netlify.com](https://netlify.com)
2. Sign up with GitHub/Google
3. Select "New site from Git" or drag & drop `index.html`
4. Configure:
   ```
   Build command: (none - leave empty)
   Publish directory: .
   ```
5. Deploy and get instant HTTPS URL

### 2. Vercel

**Pros:** Optimized for web apps, great performance, GitHub integration  
**Cons:** Paid plans after free tier

**Steps:**
1. Go to [vercel.com](https://vercel.com)
2. Import Git repository or upload files
3. Configure (no build required for static files)
4. Deploy with one click

### 3. AWS S3 + CloudFront

**Pros:** Highly scalable, reliable, enterprise-grade  
**Cons:** Requires AWS knowledge, small learning curve

**Steps:**
```bash
# 1. Create S3 bucket
aws s3 mb s3://vogg-platform

# 2. Upload index.html
aws s3 cp index.html s3://vogg-platform/ --acl public-read

# 3. Enable website hosting
aws s3 website s3://vogg-platform/ \
  --index-document index.html \
  --error-document index.html

# 4. Create CloudFront distribution
# Use AWS Console or CLI for this
```

### 4. GitHub Pages

**Pros:** Free, easy, GitHub integration  
**Cons:** Public repositories, some limitations

**Steps:**
1. Create GitHub repository: `username.github.io`
2. Push `index.html` to main branch
3. Site available at: `https://username.github.io`

### 5. Traditional Web Hosting

**For cPanel/Shared Hosting:**
```bash
# 1. Upload via FTP
ftp yourdomain.com
# Upload index.html to public_html/

# 2. Or use File Manager in cPanel
# Navigate to public_html/
# Upload index.html

# 3. Access at: https://yourdomain.com/index.html
# Or: https://yourdomain.com/ (if set as default document)
```

---

## Server Configuration

### Nginx

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;
    
    # SSL Configuration
    ssl_certificate /etc/ssl/certs/your-cert.crt;
    ssl_certificate_key /etc/ssl/private/your-key.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    root /var/www/vogg;
    index index.html;
    
    # Cache settings
    location ~* \.(html|css|js)$ {
        expires 1h;
        add_header Cache-Control "public, immutable";
    }
    
    # SPA routing (all requests → index.html)
    location / {
        try_files $uri $uri/ =404;
        # If using client-side routing:
        # try_files $uri $uri/ /index.html;
    }
    
    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/javascript application/json;
    gzip_min_length 256;
}
```

### Apache

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    
    # Redirect to HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/your-cert.crt
    SSLCertificateKeyFile /etc/ssl/private/your-key.key
    
    DocumentRoot /var/www/vogg
    
    <Directory /var/www/vogg>
        Options -MultiViews
        AllowOverride All
        
        # SPA routing
        RewriteEngine On
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule ^ index.html [QSA,L]
    </Directory>
    
    # Gzip compression
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/plain text/html text/css
        AddOutputFilterByType DEFLATE application/javascript application/json
    </IfModule>
</VirtualHost>
```

### Docker

```dockerfile
# Dockerfile
FROM nginx:alpine

# Copy application
COPY index.html /usr/share/nginx/html/index.html

# Copy Nginx config
COPY nginx.conf /etc/nginx/conf.d/default.conf

# Expose ports
EXPOSE 80 443

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD wget --quiet --tries=1 --spider http://localhost/ || exit 1

CMD ["nginx", "-g", "daemon off;"]
```

```bash
# Build & run
docker build -t vogg-platform .
docker run -p 80:80 -p 443:443 vogg-platform
```

---

## SSL/HTTPS Setup

### Using Let's Encrypt (Free)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Generate certificate
sudo certbot certonly --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renew (runs daily)
sudo systemctl enable certbot.timer
```

### Commercial Certificate
1. Order from provider (GoDaddy, Namecheap, DigiCert, etc.)
2. Verify domain ownership
3. Download certificate files
4. Configure in web server
5. Test with SSL checker: https://www.sslshopper.com/ssl-checker.html

---

## Performance Optimization

### 1. Enable Compression
```bash
# Verify gzip is enabled
curl -H "Accept-Encoding: gzip" -I https://yourdomain.com/

# Should see: Content-Encoding: gzip
```

### 2. Browser Caching
```nginx
# Cache for 1 hour
location ~* \.(html)$ {
    expires 1h;
}

# Cache for 1 year (versioned assets)
location ~* \.(css|js)$ {
    expires 1y;
}
```

### 3. Content Delivery Network (CDN)
- **Cloudflare** (free tier available)
- **Bunny CDN**
- **AWS CloudFront**

**Cloudflare Setup:**
1. Sign up at cloudflare.com
2. Add your domain
3. Update DNS nameservers
4. Enable caching rules
5. Instant performance boost

### 4. Page Speed Test
```bash
# Test with Lighthouse
curl -H "accept: application/json" \
  https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=yourdomain.com

# Use online tools:
# - PageSpeed Insights
# - GTmetrix
# - WebPageTest
```

---

## Security Checklist

- [ ] HTTPS enabled (SSL certificate)
- [ ] Security headers configured:
  ```
  X-Content-Type-Options: nosniff
  X-Frame-Options: SAMEORIGIN
  X-XSS-Protection: 1; mode=block
  Strict-Transport-Security: max-age=31536000
  Content-Security-Policy: default-src 'self'
  ```
- [ ] CORS properly configured (if needed)
- [ ] Rate limiting implemented
- [ ] DDoS protection enabled (Cloudflare/AWS WAF)
- [ ] Regular backups scheduled
- [ ] Monitoring & alerts configured
- [ ] Access logs reviewed

---

## Monitoring & Uptime

### Uptime Monitoring
- **Uptimerobot** (free)
- **Statuspage.io**
- **Pingdom**

### Error Tracking
- **Sentry** (error reporting)
- **Rollbar** (real-time monitoring)
- **Google Analytics** (traffic & behavior)

### Log Management
```bash
# Nginx logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# Check response times
grep "GET /index.html" /var/log/nginx/access.log | awk '{print $NF}' | tail -100
```

---

## Database Integration (Future)

When adding backend API:

```javascript
// Example: Fetch governance data
async function loadGovernmentData() {
    try {
        const response = await fetch('https://api.yourdomain.com/government');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error loading data:', error);
        return null;
    }
}
```

---

## Troubleshooting

### 404 on Refresh
**Problem:** Module pages return 404 when directly accessed  
**Solution:** Configure server to route all requests to index.html

```nginx
try_files $uri /index.html;
```

### CSS/JS Not Loading
**Problem:** Resources return 404  
**Solution:** Verify file paths and permissions
```bash
chmod 755 /var/www/vogg
chmod 644 /var/www/vogg/index.html
```

### Slow Loading
**Problem:** Site loads slowly  
**Solution:** Enable caching, compression, and CDN

### Mixed Content Warning
**Problem:** HTTPS page loading HTTP resources  
**Solution:** Ensure all resources use HTTPS

---

## Backup & Disaster Recovery

```bash
# Backup strategy
0 2 * * * tar -czf /backups/vogg-$(date +\%Y\%m\%d).tar.gz /var/www/vogg/

# Keep 30 days of backups
find /backups -name "vogg-*.tar.gz" -mtime +30 -delete

# Restore from backup
tar -xzf /backups/vogg-20250620.tar.gz -C /
```

---

## Version Control

```bash
# Initialize Git repository
git init
git add index.html README.md DEPLOYMENT.md
git commit -m "Initial commit: VOGG Platform v1.0.0"
git remote add origin https://github.com/yourusername/vogg-platform.git
git push -u origin main

# Deploy with GitHub Actions
# .github/workflows/deploy.yml
name: Deploy to Production
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to server
        run: |
          scp index.html user@server:/var/www/vogg/
```

---

## Support & Troubleshooting

**Common Issues:**

1. **Sidebar not toggling on mobile**
   - Check browser console for JS errors
   - Verify CSS media queries loaded

2. **Search not working**
   - This is a placeholder - implement backend integration

3. **Module not loading**
   - Check data-module attribute matches module name
   - Verify module exists in app.modules object

4. **Styling looks off**
   - Clear browser cache (Ctrl+Shift+Delete)
   - Check CSS variables are defined
   - Verify no CSS conflicts

---

**Need Help?** Contact: Prince Glory Ajurunwo  
**Email:** info@rainbowvogg.com  
**Phone:** [Contact info]

---

**Last Updated:** June 20, 2025  
**Version:** 1.0.0
