# VOGG ENTERPRISE CODING STANDARDS

**Date:** June 26, 2025  
**Version:** 1.0  
**Status:** ✅ Final & Mandatory  
**Purpose:** Official coding standards for all VOGG development  
**Owner:** Chief Architect  
**Scope:** All TypeScript, JavaScript, React, Node.js code  

---

## PART 1: TYPESCRIPT STANDARDS

### 1.1 Compiler Configuration

**tsconfig.json Requirements:**
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "lib": ["ES2020"],
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "noImplicitThis": true,
    "alwaysStrict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  }
}
```

**Mandatory Requirements:**
- ✅ `strict: true` (always)
- ✅ `noImplicitAny: true` (no implicit any)
- ✅ `noUnusedLocals: true` (catch dead code)
- ✅ `noImplicitReturns: true` (explicit returns)

---

### 1.2 Naming Conventions

**Classes & Interfaces:**
```typescript
// ✅ GOOD
class VoteService { }
interface IVote { }
interface Vote { }  // Preferred (no I prefix)
class VoteController { }

// ❌ BAD
class voteService { }
class vote_service { }
class VOTESERVICE { }
```

**Functions & Variables:**
```typescript
// ✅ GOOD
function createVote(voteData: VoteInput): Vote { }
const voteCount: number = 0;
let currentUser: User;

// ❌ BAD
function createvote(voteData) { }
function Create_Vote(voteData: any) { }
const vote_count = 0;  // Should be camelCase
```

**Constants:**
```typescript
// ✅ GOOD
const MAX_VOTES_PER_USER = 1;
const ADMIN_ROLE = 'admin';
const API_TIMEOUT_MS = 5000;

// ❌ BAD
const maxVotesPerUser = 1;  // Should be UPPER_SNAKE_CASE
const MAX_votes = 1;
```

**Files & Folders:**
```
// ✅ GOOD
src/
├── modules/
│   ├── votes/
│   ├── users/
│   └── organizations/
├── middleware/
├── types/
└── utils/

// ❌ BAD
src/
├── Modules/          # Should be lowercase
├── MIDDLEWARE/       # Should be lowercase
├── Types/            # Should be lowercase
└── Vote_Utils/       # Should be votes-utils (kebab-case)
```

---

### 1.3 Type Safety

**Always Use Explicit Types:**
```typescript
// ✅ GOOD
function createVote(data: VoteInput): Promise<Vote> {
  const voteId: string = generateId();
  const status: VoteStatus = 'draft';
  return Promise.resolve(newVote);
}

const users: User[] = [];
const metadata: Record<string, unknown> = {};

// ❌ BAD
function createVote(data: any): any {
  const voteId = generateId();  // No type
  const status = 'draft';        // No type
  return Promise.resolve(newVote);
}

const users = [];               // No type
const metadata = {};            // No type
```

**Union Types:**
```typescript
// ✅ GOOD
type VoteStatus = 'draft' | 'active' | 'closed';
function getVoteCount(status: VoteStatus): number { }

// ❌ BAD
function getVoteCount(status: string): number { }  // Too permissive
function getVoteCount(status: any): number { }     // No type checking
```

**Optional Properties:**
```typescript
// ✅ GOOD
interface Vote {
  id: string;
  title: string;
  description?: string;  // Optional
}

function createVote(
  title: string,
  description?: string   // Optional parameter
): Vote { }

// ❌ BAD
interface Vote {
  id: string | undefined;  // Use optional instead
  title: string;
  description: string | null | undefined;  // Too complex
}
```

---

### 1.4 Error Handling

**Always Type Errors:**
```typescript
// ✅ GOOD
try {
  const vote = await voteService.createVote(data);
} catch (error: unknown) {
  if (error instanceof VoteValidationError) {
    logger.warn('Invalid vote data', error.message);
  } else if (error instanceof DatabaseError) {
    logger.error('Database error', error);
    throw new AppError('Database unavailable', 500);
  } else {
    logger.error('Unknown error', error);
    throw error;
  }
}

// ❌ BAD
try {
  const vote = await voteService.createVote(data);
} catch (error) {  // No type
  logger.error(error);  // No distinction
  throw error;
}

try {
  // ...
} catch (error: any) {  // Never use 'any'
  console.log(error);   // Never use console
}
```

---

### 1.5 Comments & Documentation

**JSDoc for Public APIs:**
```typescript
// ✅ GOOD
/**
 * Create a new vote in an organization
 * 
 * @param organizationId - UUID of organization
 * @param voteData - Vote details (title, options, timing)
 * @returns Created vote object
 * @throws VoteValidationError - If validation fails
 * @throws OrganizationNotFound - If org doesn't exist
 * 
 * @example
 * const vote = await createVote('org_123', {
 *   title: 'Budget Approval?',
 *   options: ['Yes', 'No']
 * });
 */
async function createVote(
  organizationId: string,
  voteData: VoteInput
): Promise<Vote> { }

// ❌ BAD
// Create vote function
function createVote(orgId, data) { }

// Needs params and return type
```

**Inline Comments:**
```typescript
// ✅ GOOD
// Validate before creating vote (prevents invalid data in DB)
if (!isValidVoteData(voteData)) {
  throw new VoteValidationError('Invalid vote data');
}

// ❌ BAD
// Create vote
const vote = createVote();

// Loop through votes
for (const vote of votes) { }
```

---

## PART 2: NODE.JS/EXPRESS STANDARDS

### 2.1 Project Structure

**Mandatory Structure:**
```
src/
├── modules/                    # Feature modules
│   ├── votes/
│   │   ├── votes.controller.ts
│   │   ├── votes.service.ts
│   │   ├── votes.repository.ts
│   │   ├── votes.routes.ts
│   │   ├── votes.types.ts
│   │   └── votes.test.ts
│   ├── users/
│   └── organizations/
├── middleware/                 # Express middleware
│   ├── auth.ts
│   ├── errorHandler.ts
│   ├── validation.ts
│   └── logging.ts
├── config/                     # Configuration
│   ├── env.ts
│   ├── database.ts
│   └── logger.ts
├── shared/                     # Shared code
│   ├── types.ts
│   ├── errors.ts
│   ├── decorators.ts
│   └── guards.ts
├── utils/                      # Utility functions
│   ├── crypto.ts
│   ├── validation.ts
│   └── date.ts
├── app.ts                      # Express app setup
├── server.ts                   # Server entry point
└── index.ts                    # Exports
```

---

### 2.2 HTTP Handler Pattern

**Controller Pattern:**
```typescript
// ✅ GOOD
import { Request, Response, NextFunction } from 'express';
import { VoteService } from './votes.service';

export class VoteController {
  constructor(private voteService: VoteService) {}

  async createVote(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const vote = await this.voteService.createVote(req.body);
      res.status(201).json({
        success: true,
        data: vote
      });
    } catch (error) {
      next(error);  // Pass to error handler
    }
  }
}

// ❌ BAD
app.post('/votes', (req, res) => {
  const vote = voteService.createVote(req.body);
  res.json(vote);  // No error handling
});
```

---

### 2.3 Service Layer

**Business Logic Isolation:**
```typescript
// ✅ GOOD
export class VoteService {
  constructor(private repository: VoteRepository) {}

  async createVote(data: VoteInput): Promise<Vote> {
    // Validate
    this.validateVoteData(data);

    // Create
    const vote = await this.repository.create({
      ...data,
      status: 'draft'
    });

    // Return
    return vote;
  }

  private validateVoteData(data: VoteInput): void {
    if (!data.title) throw new ValidationError('Title required');
    if (data.options.length < 2) throw new ValidationError('Need 2+ options');
  }
}

// ❌ BAD
app.post('/votes', async (req, res) => {
  // Business logic in controller
  const vote = new Vote();
  vote.title = req.body.title;
  await db.insert(vote);
  res.json(vote);
});
```

---

## PART 3: DATABASE STANDARDS

### 3.1 Prisma Conventions

**Schema Naming:**
```prisma
// ✅ GOOD
model Vote {
  id            String    @id @default(uuid()) @db.Uuid
  organizationId String   @db.Uuid
  title         String    @db.VarChar(255)
  status        String    @default("draft")
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  
  organization  Entity    @relation(fields: [organizationId], references: [id])
}

// ❌ BAD
model vote {                // Should be PascalCase
  id String
  org_id String             // Should be camelCase in code
  TITLE String              // Should be lowercase
  created_at DateTime       // Should be camelCase
}
```

---

## PART 4: API STANDARDS

### 4.1 Endpoint Naming

**RESTful Conventions:**
```
// ✅ GOOD
GET    /api/v1/organizations              # List
POST   /api/v1/organizations              # Create
GET    /api/v1/organizations/{id}         # Get one
PUT    /api/v1/organizations/{id}         # Update
DELETE /api/v1/organizations/{id}         # Delete

GET    /api/v1/organizations/{id}/members # Sub-resource list
POST   /api/v1/organizations/{id}/members # Add to sub-resource

// ❌ BAD
GET    /api/v1/getOrganization            # Verb in URL
POST   /api/v1/createOrganization         # Verb in URL
DELETE /api/v1/organization/remove/{id}   # Wrong structure
GET    /api/v1/Org/{id}                   # Inconsistent naming
```

---

### 4.2 Response Format

**Consistent Response Structure:**
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "timestamp": "2025-06-26T12:00:00Z",
    "version": "1.0"
  }
}
```

---

## PART 5: LOGGING STANDARDS

### 5.1 Logger Usage

**Correct Logging:**
```typescript
// ✅ GOOD
import { logger } from '../config/logger';

logger.info('User registered', { userId: user.id, email: user.email });
logger.warn('Slow query', { query, duration: 500 });
logger.error('Vote creation failed', { voteId, error: error.message });

// ❌ BAD
console.log('User registered');           // Never use console
console.error(error);                      // Never use console
logger.info(error);                        // Log structure matters
logger.error('Something went wrong');      # No context
```

**Structured Logging:**
```typescript
// ✅ GOOD - Structured with context
logger.info('vote_created', {
  voteId: vote.id,
  organizationId: vote.organizationId,
  title: vote.title,
  timestamp: new Date().toISOString()
});

// ❌ BAD - Unstructured
logger.info('Vote created successfully with ID ' + vote.id);
```

---

## SUMMARY OF MANDATORY STANDARDS

| Standard | Rule | Enforcement |
|----------|------|------------|
| **Strict TypeScript** | `strict: true` | Build fails if violated |
| **No `any` Type** | Explicit types always | Code review blocks |
| **JSDoc for Public** | Document all exports | Code review blocks |
| **Error Handling** | Try/catch with types | Code review blocks |
| **Naming** | camelCase/PascalCase/UPPER_SNAKE_CASE | ESLint enforces |
| **No Console** | Use logger only | ESLint enforces |
| **Type Safety** | Explicit types | Build fails |

---

**Coding Standards Complete**  
**Status:** ✅ Mandatory for all development  
**Enforcement:** Automated + Code Review

