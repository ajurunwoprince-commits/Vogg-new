// Theme toggle
const themeToggle = document.getElementById('theme-toggle');
if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
  });
}

// Load saved theme
if (localStorage.getItem('theme') === 'dark') {
  document.body.classList.add('dark-mode');
}

// Search functionality
function searchDocs() {
  const query = document.getElementById('search-input').value.toLowerCase();
  const results = document.querySelectorAll('.search-result');
  results.forEach(result => {
    result.style.display = result.textContent.toLowerCase().includes(query) ? 'block' : 'none';
  });
}

// Navigation
function navigateTo(page) {
  window.location.href = page;
}

// Sidebar navigation active state
function setActiveNav(item) {
  document.querySelectorAll('.sidebar-item').forEach(el => {
    el.classList.remove('active');
  });
  item.classList.add('active');
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});
